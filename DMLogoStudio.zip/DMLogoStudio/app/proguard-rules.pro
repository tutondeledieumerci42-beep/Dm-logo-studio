# R8/ProGuard : minification desactivee dans cette premiere version
