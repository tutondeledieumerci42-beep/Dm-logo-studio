package com.dmlogostudio.core

import com.dmlogostudio.core.engine.Geometry
import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import com.dmlogostudio.core.model.ShapeType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeometryTest {

    private fun rect(rotation: Float = 0f, shape: ShapeType = ShapeType.RECTANGLE) = LogoObject(
        id = "a", kind = ObjectKind.SHAPE, shape = shape,
        cx = 500f, cy = 500f, width = 200f, height = 100f, rotation = rotation,
    )

    @Test
    fun hitInsideAndOutsideUnrotated() {
        val o = rect()
        assertTrue(Geometry.hit(o, 590f, 540f))
        assertFalse(Geometry.hit(o, 620f, 500f))
    }

    @Test
    fun hitRespectsRotation() {
        val o = rect(rotation = 90f)
        // Après 90°, l'objet est haut de 200 et large de 100.
        assertTrue(Geometry.hit(o, 500f, 590f))
        assertFalse(Geometry.hit(o, 590f, 500f))
    }

    @Test
    fun ellipseCornerIsAMiss() {
        val o = rect(shape = ShapeType.ELLIPSE)
        assertTrue(Geometry.hit(o, 500f, 500f))
        assertFalse(Geometry.hit(o, 595f, 545f))
    }

    @Test
    fun localAndSceneConversionsAreInverse() {
        val o = rect(rotation = 37f)
        val l = Geometry.toLocal(o, 640f, 420f)
        val back = Geometry.toScene(o, l.x, l.y)
        assertEquals(640f, back.x, 0.01f)
        assertEquals(420f, back.y, 0.01f)
    }

    @Test
    fun hitTestPicksTopMostObject() {
        val below = rect().copy(id = "below")
        val above = rect().copy(id = "above")
        val scene = Scene(objects = listOf(below, above))
        assertEquals("above", Geometry.hitTest(scene, 500f, 500f)?.id)
        assertNull(Geometry.hitTest(scene, 10f, 10f))
    }
}
