package com.dmlogostudio.core

import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import com.dmlogostudio.core.model.ShapeType
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Test

class SceneSerializationTest {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Test
    fun sceneSurvivesJsonRoundTrip() {
        val scene = Scene(
            backgroundColor = 0xFF0B1F3A,
            objects = listOf(
                LogoObject(
                    id = "1", kind = ObjectKind.SHAPE, shape = ShapeType.STAR,
                    cx = 400f, cy = 300f, width = 250f, height = 250f, rotation = 15f,
                    fillColor = 0xFFD4AF37, strokeWidth = 6f, opacity = 0.8f,
                ),
                LogoObject(
                    id = "2", kind = ObjectKind.TEXT, cx = 500f, cy = 700f,
                    width = 420f, height = 140f, text = "DM Studio", fontFamily = "serif", bold = true,
                ),
            ),
        )
        val decoded = json.decodeFromString<Scene>(json.encodeToString(scene))
        assertEquals(scene, decoded)
    }

    @Test
    fun unknownFieldsAreIgnored() {
        val decoded = json.decodeFromString<Scene>("""{"width":800,"futureField":1}""")
        assertEquals(800f, decoded.width, 0f)
    }
}
