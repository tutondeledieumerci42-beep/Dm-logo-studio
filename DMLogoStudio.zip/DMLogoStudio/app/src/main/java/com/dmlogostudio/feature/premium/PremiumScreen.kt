package com.dmlogostudio.feature.premium

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dmlogostudio.DmLogoApp
import com.dmlogostudio.ui.theme.Gold
import com.dmlogostudio.ui.theme.GoldSoft
import com.dmlogostudio.ui.theme.Ink
import com.dmlogostudio.ui.theme.Panel

private data class ComparisonRow(val feature: String, val free: String, val premium: String)

private val comparison = listOf(
    ComparisonRow("Bibliothèque de formes", "16 formes géométriques", "Organiques, emblèmes, décoratives (à venir)"),
    ComparisonRow("Dessin et tracés", "—", "Lignes, flèches, main levée (à venir)"),
    ComparisonRow("Édition vectorielle", "—", "Points d'ancrage, fusion, soustraction (à venir)"),
    ComparisonRow("Couleurs", "Couleurs unies, contour", "Dégradés avancés, ombres, textures (à venir)"),
    ComparisonRow("Export", "—", "PNG, SVG, PDF (à venir)"),
    ComparisonRow("Calques et annuler/rétablir", "Inclus", "Inclus"),
    ComparisonRow("Sauvegarde locale", "Inclus", "Inclus"),
)

/** Écran honnête : aucune fonction Premium n'est encore construite, donc rien
 *  n'est à vendre pour l'instant. On l'affiche quand même pour montrer où va
 *  le projet, sans jamais simuler un achat qui n'existe pas. */
@Composable
fun PremiumScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as DmLogoApp
    val isPremium by app.entitlements.isPremium.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding(),
    ) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
            Text("Premium", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
        ) {
            Text(
                if (isPremium) "Vous utilisez déjà DM LOGO STUDIO Premium." else "Vous utilisez actuellement la version gratuite.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "DM LOGO STUDIO Premium n'est pas encore disponible à l'achat : les outils " +
                    "ci-dessous sont la feuille de route du studio, pas des fonctions déjà " +
                    "construites. Rien n'est caché ni simulé — ce tableau sera mis à jour au " +
                    "fur et à mesure qu'ils seront réellement développés.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(20.dp))

            comparison.forEach { row -> ComparisonCard(row) }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {},
                enabled = false,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(
                    disabledContainerColor = Panel,
                    disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            ) {
                Icon(Icons.Filled.HourglassEmpty, contentDescription = null, modifier = Modifier.height(20.dp))
                Spacer(Modifier.height(0.dp))
                Text("  Premium — bientôt disponible")
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun ComparisonCard(row: ComparisonRow) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Panel)
            .padding(14.dp),
    ) {
        Text(row.feature, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Row {
            Column(Modifier.weight(1f)) {
                Text("Free", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                FeatureLine(row.free, done = row.free != "—")
            }
            Column(Modifier.weight(1f)) {
                Text("Premium", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                FeatureLine(row.premium, done = row.premium == "Inclus")
            }
        }
    }
}

@Composable
private fun FeatureLine(text: String, done: Boolean) {
    Row(verticalAlignment = Alignment.Top) {
        if (done) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = GoldSoft, modifier = Modifier.height(14.dp))
            Spacer(Modifier.height(0.dp))
        }
        Text(text, fontSize = 12.sp, color = Color.White, modifier = Modifier.padding(start = if (done) 4.dp else 0.dp))
    }
}
