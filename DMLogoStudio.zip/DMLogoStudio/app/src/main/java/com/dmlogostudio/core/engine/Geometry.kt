package com.dmlogostudio.core.engine

import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import com.dmlogostudio.core.model.ShapeType
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class Pt(val x: Float, val y: Float)

/** Mathématiques pures (sans dépendance Android) : testables en JVM. */
object Geometry {

    /** Convertit un point de la scène vers le repère local de l'objet (centre = 0,0, sans rotation). */
    fun toLocal(o: LogoObject, px: Float, py: Float): Pt {
        val r = Math.toRadians(-o.rotation.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        val dx = px - o.cx
        val dy = py - o.cy
        return Pt(dx * c - dy * s, dx * s + dy * c)
    }

    /** Convertit un point du repère local de l'objet vers la scène. */
    fun toScene(o: LogoObject, lx: Float, ly: Float): Pt {
        val r = Math.toRadians(o.rotation.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return Pt(o.cx + lx * c - ly * s, o.cy + lx * s + ly * c)
    }

    fun hit(o: LogoObject, px: Float, py: Float, slop: Float = 0f): Boolean {
        val l = toLocal(o, px, py)
        val hw = o.width / 2f + slop
        val hh = o.height / 2f + slop
        if (abs(l.x) > hw || abs(l.y) > hh) return false
        if (o.kind == ObjectKind.SHAPE && o.shape == ShapeType.ELLIPSE) {
            val nx = l.x / hw
            val ny = l.y / hh
            return nx * nx + ny * ny <= 1f
        }
        return true
    }

    /** Objet le plus haut dans la pile situé sous le point, ou null. */
    fun hitTest(scene: Scene, px: Float, py: Float, slop: Float = 0f): LogoObject? =
        scene.objects.lastOrNull { hit(it, px, py, slop) }

    fun resizeHandle(o: LogoObject): Pt = toScene(o, o.width / 2f, o.height / 2f)

    fun rotateHandle(o: LogoObject, viewScale: Float): Pt =
        toScene(o, 0f, -o.height / 2f - 44f / viewScale)

    fun distance(a: Pt, b: Pt): Float = hypot(a.x - b.x, a.y - b.y)
}
