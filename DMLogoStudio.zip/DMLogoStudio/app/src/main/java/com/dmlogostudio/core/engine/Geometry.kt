package com.dmlogostudio.core.engine

import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import com.dmlogostudio.core.model.ShapeType
import com.dmlogostudio.core.model.isOpenPath
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

data class Pt(val x: Float, val y: Float)

/** Mathématiques pures (sans dépendance Android) : testables en JVM. */
object Geometry {

    /** Convertit un point de la scène vers le repère local de l'objet (centre = 0,0, sans rotation). */
    fun toLocal(o: LogoObject, px: Float, py: Float): Pt {
        val r = Math.toRadians(-o.rotation.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        val dx = px - o.cx
        val dy = py - o.cy
        return Pt(dx * c - dy * s, dx * s + dy * c)
    }

    /** Convertit un point du repère local de l'objet vers la scène. */
    fun toScene(o: LogoObject, lx: Float, ly: Float): Pt {
        val r = Math.toRadians(o.rotation.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return Pt(o.cx + lx * c - ly * s, o.cy + lx * s + ly * c)
    }

    fun hit(o: LogoObject, px: Float, py: Float, slop: Float = 0f): Boolean {
        val l = toLocal(o, px, py)
        val hw = o.width / 2f + slop
        val hh = o.height / 2f + slop
        if (abs(l.x) > hw || abs(l.y) > hh) return false
        if (o.kind == ObjectKind.SHAPE && o.shape.isOpenPath()) {
            // Un tracé ouvert ne se sélectionne qu'en touchant vraiment le trait,
            // pas n'importe où dans son cadre englobant.
            val tolerance = max(o.strokeWidth / 2f, 22f) + slop
            return distanceToPath(o, l.x, l.y) <= tolerance
        }
        if (o.kind == ObjectKind.SHAPE && o.shape == ShapeType.ELLIPSE) {
            val nx = l.x / hw
            val ny = l.y / hh
            return nx * nx + ny * ny <= 1f
        }
        return true
    }

    /** Distance entre (lx,ly) et le tracé réel de l'objet (espace local, sans
     *  rotation), en échantillonnant le Path déjà utilisé pour le dessiner. */
    private fun distanceToPath(o: LogoObject, lx: Float, ly: Float): Float {
        val path = ShapePaths.build(o)
        val measure = android.graphics.PathMeasure(path, false)
        var minDist = Float.MAX_VALUE
        val pos = FloatArray(2)
        do {
            val len = measure.length
            if (len > 0f) {
                val steps = 28
                var prevX = 0f
                var prevY = 0f
                var hasPrev = false
                for (i in 0..steps) {
                    measure.getPosTan(len * i / steps, pos, null)
                    if (hasPrev) {
                        val d = distanceToSegment(lx, ly, prevX, prevY, pos[0], pos[1])
                        if (d < minDist) minDist = d
                    }
                    prevX = pos[0]
                    prevY = pos[1]
                    hasPrev = true
                }
            }
        } while (measure.nextContour())
        return minDist
    }

    private fun distanceToSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val lenSq = dx * dx + dy * dy
        val t = if (lenSq > 0.0001f) (((px - ax) * dx + (py - ay) * dy) / lenSq).coerceIn(0f, 1f) else 0f
        val cx = ax + t * dx
        val cy = ay + t * dy
        return hypot(px - cx, py - cy)
    }

    /** Objet le plus haut dans la pile situé sous le point, ou null. */
    fun hitTest(scene: Scene, px: Float, py: Float, slop: Float = 0f): LogoObject? =
        scene.objects.lastOrNull { hit(it, px, py, slop) }

    fun resizeHandle(o: LogoObject): Pt = toScene(o, o.width / 2f, o.height / 2f)

    fun rotateHandle(o: LogoObject, viewScale: Float): Pt =
        toScene(o, 0f, -o.height / 2f - 44f / viewScale)

    fun distance(a: Pt, b: Pt): Float = hypot(a.x - b.x, a.y - b.y)
}
