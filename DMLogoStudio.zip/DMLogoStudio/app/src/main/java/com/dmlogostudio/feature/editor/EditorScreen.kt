package com.dmlogostudio.feature.editor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.dmlogostudio.DmLogoApp
import com.dmlogostudio.core.engine.Geometry
import com.dmlogostudio.core.engine.Pt
import com.dmlogostudio.core.engine.SceneRenderer
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import com.dmlogostudio.core.model.ShapeType
import com.dmlogostudio.ui.theme.Gold
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun EditorScreen(projectId: String, onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as DmLogoApp
    val vm: EditorViewModel = viewModel(
        key = projectId,
        factory = viewModelFactory { initializer { EditorViewModel(app.repository, projectId) } },
    )
    val ui by vm.state.collectAsState()

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.flush() }
    BackHandler {
        vm.flush()
        onBack()
    }
    if (ui.missing) {
        LaunchedEffect(Unit) { onBack() }
    }

    var drawMode by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .imePadding(),
    ) {
        EditorTopBar(ui, vm, onBack = { vm.flush(); onBack() })
        EditorCanvas(ui, vm, drawMode, Modifier.weight(1f).fillMaxWidth())
        ToolRow(ui, vm, drawMode, onToggleDraw = { drawMode = !drawMode })
        PropertyPanel(ui, vm)
    }
}

// ---------------------------------------------------------------- barre du haut

@Composable
private fun EditorTopBar(ui: EditorUiState, vm: EditorViewModel, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var exporting by androidx.compose.runtime.remember { mutableStateOf(false) }

    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
        Text(
            ui.name,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.SemiBold,
        )
        IconButton(onClick = vm::undo, enabled = ui.canUndo) {
            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Annuler")
        }
        IconButton(onClick = vm::redo, enabled = ui.canRedo) {
            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Rétablir")
        }
        IconButton(
            enabled = !exporting,
            onClick = {
                exporting = true
                val scene = ui.scene
                val name = ui.name
                scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                    val uri = com.dmlogostudio.core.export.PngExporter.export(context, scene, name)
                    exporting = false
                    withContext(kotlinx.coroutines.Dispatchers.Main) {
                        val message = if (uri != null) {
                            "Exporté dans Images/DM Logo Studio"
                        } else {
                            "Échec de l'export PNG"
                        }
                        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            },
        ) {
            Icon(Icons.Filled.FileDownload, contentDescription = "Exporter en PNG")
        }
    }
}

// ---------------------------------------------------------------- canevas

private enum class DragMode { NONE, MOVE, RESIZE, ROTATE }

private data class Viewport(val scale: Float, val ox: Float, val oy: Float) {
    fun toScene(x: Float, y: Float) = Pt((x - ox) / scale, (y - oy) / scale)
}

private fun viewport(size: IntSize, scene: Scene): Viewport {
    if (size.width == 0 || size.height == 0) return Viewport(1f, 0f, 0f)
    val s = min(size.width / scene.width, size.height / scene.height) * 0.92f
    return Viewport(s, (size.width - scene.width * s) / 2f, (size.height - scene.height * s) / 2f)
}

@Composable
private fun EditorCanvas(ui: EditorUiState, vm: EditorViewModel, drawMode: Boolean, modifier: Modifier) {
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    val uiNow by rememberUpdatedState(ui)
    val drawModeNow by rememberUpdatedState(drawMode)
    var mode by remember { mutableStateOf(DragMode.NONE) }
    var currentStroke by remember { mutableStateOf(listOf<androidx.compose.ui.geometry.Offset>()) }

    Canvas(
        modifier = modifier
            .background(Color(0xFF2A2A30))
            .onSizeChanged { viewSize = it }
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    if (drawModeNow) return@detectTapGestures
                    val cur = uiNow
                    val vp = viewport(viewSize, cur.scene)
                    val p = vp.toScene(pos.x, pos.y)
                    vm.select(Geometry.hitTest(cur.scene, p.x, p.y, 8f / vp.scale)?.id)
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { pos ->
                        val vp = viewport(viewSize, uiNow.scene)
                        if (drawModeNow) {
                            val p = vp.toScene(pos.x, pos.y)
                            currentStroke = listOf(androidx.compose.ui.geometry.Offset(p.x, p.y))
                            return@detectDragGestures
                        }
                        val cur = uiNow
                        val p = vp.toScene(pos.x, pos.y)
                        val sel = cur.selected
                        val grab = 28f / vp.scale
                        mode = when {
                            sel != null && Geometry.distance(Geometry.resizeHandle(sel), p) < grab -> DragMode.RESIZE
                            sel != null && Geometry.distance(Geometry.rotateHandle(sel, vp.scale), p) < grab -> DragMode.ROTATE
                            else -> {
                                val hit = Geometry.hitTest(cur.scene, p.x, p.y, 8f / vp.scale)
                                if (hit != null) {
                                    vm.select(hit.id)
                                    DragMode.MOVE
                                } else DragMode.NONE
                            }
                        }
                        if (mode != DragMode.NONE) vm.beginGesture()
                    },
                    onDrag = { change, dragAmount ->
                        val vp = viewport(viewSize, uiNow.scene)
                        if (drawModeNow) {
                            change.consume()
                            val p = vp.toScene(change.position.x, change.position.y)
                            currentStroke = currentStroke + androidx.compose.ui.geometry.Offset(p.x, p.y)
                            return@detectDragGestures
                        }
                        if (mode != DragMode.NONE) {
                            change.consume()
                            val p = vp.toScene(change.position.x, change.position.y)
                            when (mode) {
                                DragMode.MOVE -> vm.moveSelected(dragAmount.x / vp.scale, dragAmount.y / vp.scale)
                                DragMode.RESIZE -> vm.resizeSelectedTo(p.x, p.y)
                                DragMode.ROTATE -> vm.rotateSelectedTo(p.x, p.y)
                                DragMode.NONE -> Unit
                            }
                        }
                    },
                    onDragEnd = {
                        if (drawModeNow) {
                            vm.commitFreehand(currentStroke)
                            currentStroke = emptyList()
                        }
                        mode = DragMode.NONE
                    },
                    onDragCancel = {
                        currentStroke = emptyList()
                        mode = DragMode.NONE
                    },
                )
            },
    ) {
        val vp = viewport(IntSize(size.width.roundToInt(), size.height.roundToInt()), ui.scene)
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            nc.save()
            nc.translate(vp.ox, vp.oy)
            nc.scale(vp.scale, vp.scale)
            SceneRenderer.drawScene(nc, ui.scene)
            ui.selected?.let { SelectionOverlay.draw(nc, it, vp.scale) }
            if (currentStroke.size >= 2) {
                val preview = android.graphics.Path()
                preview.moveTo(currentStroke[0].x, currentStroke[0].y)
                for (i in 1 until currentStroke.size) preview.lineTo(currentStroke[i].x, currentStroke[i].y)
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE
                    strokeWidth = 10f
                    strokeCap = android.graphics.Paint.Cap.ROUND
                    strokeJoin = android.graphics.Paint.Join.ROUND
                    color = 0xFFBE8922.toInt()
                }
                nc.drawPath(preview, paint)
            }
            nc.restore()
        }
    }
}

// ---------------------------------------------------------------- barre d'outils

@Composable
private fun ToolRow(ui: EditorUiState, vm: EditorViewModel, drawMode: Boolean, onToggleDraw: () -> Unit) {
    val hasSel = ui.selected != null
    var shapeMenu by remember { mutableStateOf(false) }
    var polygonMenu by remember { mutableStateOf(false) }
    var lineMenu by remember { mutableStateOf(false) }
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        ToolButton(
            icon = Icons.Filled.Edit,
            label = if (drawMode) "Dessin : ON" else "Dessiner",
            enabled = true,
            tintOverride = if (drawMode) Gold else null,
            onClick = onToggleDraw,
        )
        Box {
            ToolButton(Icons.Filled.Category, "Forme", !drawMode) { shapeMenu = true }
            DropdownMenu(
                expanded = shapeMenu,
                onDismissRequest = { shapeMenu = false },
                modifier = Modifier.heightIn(max = 420.dp),
            ) {
                Text(
                    "Géométriques",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                )
                GeometricShapes.forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type.label()) },
                        onClick = {
                            shapeMenu = false
                            vm.addShape(type)
                        },
                    )
                }
                DropdownMenuItem(
                    text = { Text("Polygones  ▸") },
                    onClick = {
                        shapeMenu = false
                        polygonMenu = true
                    },
                )
                DropdownMenuItem(
                    text = { Text("Lignes et flèches  ▸") },
                    onClick = {
                        shapeMenu = false
                        lineMenu = true
                    },
                )
                androidx.compose.material3.Divider()
                Text(
                    "Bientôt disponible",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                )
                UpcomingShapeCategories.forEach { label ->
                    DropdownMenuItem(
                        text = { Text(label, color = MaterialTheme.colorScheme.outline) },
                        onClick = {},
                        enabled = false,
                    )
                }
            }
            DropdownMenu(expanded = polygonMenu, onDismissRequest = { polygonMenu = false }) {
                PolygonFamily.forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type.label()) },
                        onClick = {
                            polygonMenu = false
                            vm.addShape(type)
                        },
                    )
                }
            }
            DropdownMenu(expanded = lineMenu, onDismissRequest = { lineMenu = false }) {
                LineFamily.forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type.label()) },
                        onClick = {
                            lineMenu = false
                            vm.addShape(type)
                        },
                    )
                }
            }
        }
        ToolButton(Icons.Filled.TextFields, "Texte", true) { vm.addText() }
        ToolButton(Icons.Filled.ContentCopy, "Dupliquer", hasSel) { vm.duplicateSelected() }
        ToolButton(Icons.Filled.ArrowUpward, "Avant", hasSel) { vm.bringForward() }
        ToolButton(Icons.Filled.ArrowDownward, "Arrière", hasSel) { vm.sendBackward() }
        ToolButton(Icons.Filled.Delete, "Supprimer", hasSel) { vm.deleteSelected() }
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    tintOverride: Color? = null,
    onClick: () -> Unit,
) {
    val tint = tintOverride ?: if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    Column(
        Modifier
            .clip(MaterialTheme.shapes.small)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = tint)
        Text(label, fontSize = 11.sp, color = tint)
    }
}

// ---------------------------------------------------------------- panneau de propriétés

@Composable
private fun PropertyPanel(ui: EditorUiState, vm: EditorViewModel) {
    val sel = ui.selected
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = 250.dp)
            .background(MaterialTheme.colorScheme.surface)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (sel == null) {
            ColorRow("Fond de la planche", ui.scene.backgroundColor, allowNone = false, onPick = vm::setBackground)
            Text(
                "Touchez un objet pour le modifier. Glissez-le pour le déplacer ; " +
                    "la poignée du coin le redimensionne, celle du haut le fait pivoter.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            return@Column
        }

        if (sel.kind == ObjectKind.TEXT) {
            var field by remember(sel.id) { mutableStateOf(sel.text) }
            LaunchedEffect(sel.text) { if (field != sel.text) field = sel.text }
            OutlinedTextField(
                value = field,
                onValueChange = {
                    field = it
                    vm.setText(it)
                },
                label = { Text("Texte") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FontFamilies.forEach { (family, label) ->
                    FilterChip(
                        selected = sel.fontFamily == family,
                        onClick = { vm.setFontFamily(family) },
                        label = { Text(label) },
                    )
                }
                FilterChip(selected = sel.bold, onClick = { vm.setBold(!sel.bold) }, label = { Text("Gras") })
                FilterChip(selected = sel.italic, onClick = { vm.setItalic(!sel.italic) }, label = { Text("Italique") })
            }
            LabeledSlider("Taille", sel.fontSize, 24f..400f, "${sel.fontSize.roundToInt()}") { vm.setFontSize(it) }
        }

        if (sel.kind == ObjectKind.SHAPE && sel.shape == ShapeType.POLYGON) {
            LabeledSlider("Côtés", sel.sides.toFloat(), 3f..12f, "${sel.sides}", steps = 8) { vm.setSides(it.roundToInt()) }
        }

        ColorRow("Remplissage", sel.fillColor, allowNone = true, onPick = vm::setFill)
        ColorRow("Contour", sel.strokeColor, allowNone = false, onPick = vm::setStroke)
        LabeledSlider("Épaisseur", sel.strokeWidth, 0f..40f, "${sel.strokeWidth.roundToInt()}") { vm.setStrokeWidth(it) }
        LabeledSlider("Opacité", sel.opacity, 0f..1f, "${(sel.opacity * 100).roundToInt()} %") { vm.setOpacity(it) }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    steps: Int = 0,
    onChange: (Float) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.width(84.dp), fontSize = 13.sp)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            modifier = Modifier.weight(1f),
        )
        Text(valueText, modifier = Modifier.width(52.dp), textAlign = TextAlign.End, fontSize = 12.sp)
    }
}

@Composable
private fun ColorRow(label: String, current: Long, allowNone: Boolean, onPick: (Long) -> Unit) {
    var showHex by remember { mutableStateOf(false) }
    Text(label, fontSize = 13.sp)
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (allowNone) {
            Swatch(color = null, selected = current == NO_COLOR, label = "∅") { onPick(NO_COLOR) }
        }
        Palette.forEach { c -> Swatch(color = c, selected = c == current, label = null) { onPick(c) } }
        Swatch(color = null, selected = false, label = "#") { showHex = true }
    }
    if (showHex) {
        HexDialog(onDismiss = { showHex = false }, onConfirm = { onPick(it); showHex = false })
    }
}

@Composable
private fun Swatch(color: Long?, selected: Boolean, label: String?, onClick: () -> Unit) {
    val border = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(if (color != null) Color(color) else MaterialTheme.colorScheme.surfaceVariant)
            .border(if (selected) 3.dp else 1.dp, border, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (label != null) Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HexDialog(onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    var hex by remember { mutableStateOf("") }
    val value = hex.trim().removePrefix("#").takeIf { it.length == 6 }?.toLongOrNull(16)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Couleur personnalisée") },
        text = {
            OutlinedTextField(
                value = hex,
                onValueChange = { hex = it.take(7) },
                singleLine = true,
                label = { Text("Code hexadécimal (ex. D4AF37)") },
                prefix = { Text("#") },
            )
        },
        confirmButton = {
            TextButton(enabled = value != null, onClick = { onConfirm(0xFF000000 or (value ?: 0L)) }) { Text("Appliquer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
