package com.dmlogostudio.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dmlogostudio.ui.theme.Gold
import com.dmlogostudio.ui.theme.Ink
import com.dmlogostudio.ui.theme.Panel

/** Écran de réglages minimal mais réel : seules des informations et actions vraies y figurent. */
@Composable
fun SettingsScreen(onOpenPremium: () -> Unit, onOpenTrash: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding()
            .padding(24.dp),
    ) {
        Text("Paramètres", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        NavRow(icon = Icons.Filled.WorkspacePremium, title = "Premium", subtitle = "Voir la feuille de route et comparer avec Free", onClick = onOpenPremium)
        Spacer(Modifier.height(10.dp))
        NavRow(icon = Icons.Filled.Delete, title = "Corbeille", subtitle = "Retrouver les projets supprimés", onClick = onOpenTrash)
        Spacer(Modifier.height(20.dp))

        SettingsRow("Application", "DM LOGO STUDIO")
        SettingsRow("Version", "0.1.14")
        SettingsRow("Compte", "Non connecté — la connexion n'est pas encore disponible")
        SettingsRow("Stockage", "Local, sur cet appareil uniquement")
        SettingsRow("Connexion requise", "Non — fonctionne hors ligne")

        Spacer(Modifier.height(24.dp))
        Text(
            "Les réglages de compte arriveront avec une future mise à jour.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun NavRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Panel)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = Gold)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SettingsRow(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Text(value, fontSize = 15.sp)
    }
    Divider(color = Gold.copy(alpha = 0.15f))
}
