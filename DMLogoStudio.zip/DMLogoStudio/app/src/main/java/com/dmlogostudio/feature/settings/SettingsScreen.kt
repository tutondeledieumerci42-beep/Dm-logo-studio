package com.dmlogostudio.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dmlogostudio.ui.theme.Gold
import com.dmlogostudio.ui.theme.Ink

/** Écran de réglages minimal mais réel : seules des informations vraies y figurent. */
@Composable
fun SettingsScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .systemBarsPadding()
            .padding(24.dp),
    ) {
        Text("Paramètres", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        SettingsRow("Application", "DM LOGO STUDIO")
        SettingsRow("Version", "0.1.6")
        SettingsRow("Stockage", "Local, sur cet appareil uniquement")
        SettingsRow("Connexion requise", "Non — fonctionne hors ligne")

        Spacer(Modifier.height(24.dp))
        Text(
            "Les réglages de compte, de notifications et d'abonnement arriveront avec les futures fonctionnalités.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )
    }
}

@Composable
private fun SettingsRow(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Text(value, fontSize = 15.sp)
    }
    Divider(color = Gold.copy(alpha = 0.15f))
}
