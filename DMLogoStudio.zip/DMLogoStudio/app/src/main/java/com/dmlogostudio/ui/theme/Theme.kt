package com.dmlogostudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFD4AF37)
val GoldSoft = Color(0xFFF0D77A)
val Ink = Color(0xFF0E0E10)
val Panel = Color(0xFF1A1A1E)
val PanelHigh = Color(0xFF26262B)

private val Scheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF1A1400),
    secondary = GoldSoft,
    onSecondary = Color(0xFF1A1400),
    background = Ink,
    onBackground = Color.White,
    surface = Panel,
    onSurface = Color.White,
    surfaceVariant = PanelHigh,
    onSurfaceVariant = Color(0xFFC8C8CE),
    outline = Color(0xFF5A5A62),
    surfaceContainer = Panel,
    surfaceContainerHigh = PanelHigh,
)

@Composable
fun DmLogoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
