package com.dmlogostudio.feature.editor

import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import com.dmlogostudio.core.engine.Geometry
import com.dmlogostudio.core.model.LogoObject

/** Cadre de sélection + poignées de redimensionnement et de rotation (dessinés dans l'espace de la scène). */
object SelectionOverlay {
    private val GOLD = 0xFFD4AF37.toInt()

    fun draw(canvas: Canvas, o: LogoObject, viewScale: Float) {
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = GOLD
            strokeWidth = 2f / viewScale
            pathEffect = DashPathEffect(floatArrayOf(10f / viewScale, 8f / viewScale), 0f)
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = GOLD }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFFFFFF.toInt()
            strokeWidth = 2f / viewScale
        }
        val r = 12f / viewScale

        canvas.save()
        canvas.translate(o.cx, o.cy)
        canvas.rotate(o.rotation)
        canvas.drawRect(-o.width / 2f, -o.height / 2f, o.width / 2f, o.height / 2f, line)
        val ry = -o.height / 2f - 44f / viewScale
        canvas.drawLine(0f, -o.height / 2f, 0f, ry, line)
        canvas.drawCircle(0f, ry, r, fill)
        canvas.drawCircle(0f, ry, r, ring)
        canvas.drawCircle(o.width / 2f, o.height / 2f, r, fill)
        canvas.drawCircle(o.width / 2f, o.height / 2f, r, ring)
        canvas.restore()
    }
}
