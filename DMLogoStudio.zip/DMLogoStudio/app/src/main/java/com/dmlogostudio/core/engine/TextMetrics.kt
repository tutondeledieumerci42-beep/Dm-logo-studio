package com.dmlogostudio.core.engine

import android.graphics.Paint
import android.graphics.Typeface
import com.dmlogostudio.core.model.LogoObject
import kotlin.math.max

object TextMetrics {
    fun typeface(o: LogoObject): Typeface {
        val style = when {
            o.bold && o.italic -> Typeface.BOLD_ITALIC
            o.bold -> Typeface.BOLD
            o.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        return Typeface.create(o.fontFamily, style)
    }

    fun paint(o: LogoObject): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = typeface(o)
        textSize = o.fontSize
        textAlign = Paint.Align.CENTER
    }

    /** Taille (largeur, hauteur) de la boîte englobante du texte avant rotation. */
    fun measure(o: LogoObject): Pair<Float, Float> {
        val p = paint(o)
        val w = max(p.measureText(o.text.ifEmpty { " " }), 20f)
        val fm = p.fontMetrics
        return w to (fm.descent - fm.ascent)
    }
}
