package com.dmlogostudio.data

import com.dmlogostudio.core.model.Scene
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

data class Project(val id: String, val name: String, val updatedAt: Long, val scene: Scene)

class ProjectRepository(
    private val dao: ProjectDao,
    private val scope: CoroutineScope,
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private fun cleanName(name: String) = name.trim().ifBlank { "Sans titre" }

    private fun ProjectEntity.toProject() = Project(
        id = id,
        name = name,
        updatedAt = updatedAt,
        scene = runCatching { json.decodeFromString<Scene>(sceneJson) }.getOrElse { Scene() },
    )

    fun observeProjects(): Flow<List<Project>> =
        dao.observeAll().map { list -> list.map { it.toProject() } }

    suspend fun create(name: String): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        dao.upsert(ProjectEntity(id, cleanName(name), now, now, json.encodeToString(Scene())))
        return id
    }

    suspend fun get(id: String): Project? = dao.get(id)?.toProject()

    suspend fun saveScene(id: String, name: String, scene: Scene) {
        dao.updateContent(id, cleanName(name), System.currentTimeMillis(), json.encodeToString(scene))
    }

    /** Sauvegarde qui survit à la destruction d'un ViewModel (portée de l'application). */
    fun saveInBackground(id: String, name: String, scene: Scene) {
        scope.launch { saveScene(id, name, scene) }
    }

    suspend fun rename(id: String, name: String) {
        dao.rename(id, cleanName(name), System.currentTimeMillis())
    }

    suspend fun duplicate(id: String): String? {
        val source = dao.get(id) ?: return null
        val now = System.currentTimeMillis()
        val newId = UUID.randomUUID().toString()
        dao.upsert(source.copy(id = newId, name = source.name + " (copie)", createdAt = now, updatedAt = now))
        return newId
    }

    suspend fun delete(id: String) = dao.delete(id)
}
