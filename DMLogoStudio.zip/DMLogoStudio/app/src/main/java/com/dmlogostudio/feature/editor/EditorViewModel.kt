package com.dmlogostudio.feature.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dmlogostudio.core.engine.Geometry
import com.dmlogostudio.core.engine.TextMetrics
import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import com.dmlogostudio.core.model.ShapeType
import com.dmlogostudio.data.ProjectRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max

data class EditorUiState(
    val loaded: Boolean = false,
    val missing: Boolean = false,
    val name: String = "",
    val scene: Scene = Scene(),
    val selectedId: String? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
) {
    val selected: LogoObject? get() = scene.objects.firstOrNull { it.id == selectedId }
}

class EditorViewModel(
    private val repo: ProjectRepository,
    private val projectId: String,
) : ViewModel() {

    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    private val undoStack = ArrayDeque<Scene>()
    private val redoStack = ArrayDeque<Scene>()
    private var lastEditKey: String? = null
    private var saveJob: Job? = null

    init {
        viewModelScope.launch {
            val p = repo.get(projectId)
            _state.update {
                if (p == null) it.copy(loaded = true, missing = true)
                else it.copy(loaded = true, name = p.name, scene = p.scene)
            }
        }
    }

    // ---------- infrastructure ----------

    private fun pushUndo() {
        undoStack.addLast(_state.value.scene)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
    }

    private fun setScene(scene: Scene, selectedId: String? = _state.value.selectedId) {
        _state.update {
            it.copy(
                scene = scene,
                selectedId = selectedId,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
            )
        }
        scheduleSave()
    }

    /** Modification discrète annulable. Les modifications successives de même clé forment une seule étape d'annulation. */
    private fun edit(key: String? = null, transform: (Scene) -> Scene) {
        if (key == null || key != lastEditKey) pushUndo()
        lastEditKey = key
        setScene(transform(_state.value.scene))
    }

    private fun editSelected(key: String? = null, f: (LogoObject) -> LogoObject) {
        val id = _state.value.selectedId ?: return
        edit(key?.let { "$it:$id" }) { s ->
            s.copy(objects = s.objects.map { if (it.id == id) f(it) else it })
        }
    }

    /** Modification pendant un geste (l'étape d'annulation a été posée par beginGesture). */
    private fun liveUpdateSelected(f: (LogoObject) -> LogoObject) {
        val id = _state.value.selectedId ?: return
        val s = _state.value.scene
        setScene(s.copy(objects = s.objects.map { if (it.id == id) f(it) else it }))
    }

    private fun withMetrics(o: LogoObject): LogoObject =
        if (o.kind == ObjectKind.TEXT) {
            val (w, h) = TextMetrics.measure(o)
            o.copy(width = w, height = h)
        } else o

    private fun newId() = UUID.randomUUID().toString()

    private fun scheduleSave() {
        val st = _state.value
        if (!st.loaded || st.missing) return
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(600)
            val cur = _state.value
            repo.saveScene(projectId, cur.name, cur.scene)
        }
    }

    /** Sauvegarde immédiate, indépendante du cycle de vie du ViewModel. */
    fun flush() {
        val st = _state.value
        if (!st.loaded || st.missing) return
        saveJob?.cancel()
        repo.saveInBackground(projectId, st.name, st.scene)
    }

    override fun onCleared() {
        flush()
        super.onCleared()
    }

    // ---------- sélection / historique ----------

    fun select(id: String?) {
        lastEditKey = null
        _state.update { it.copy(selectedId = id) }
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(_state.value.scene)
        lastEditKey = null
        val sel = _state.value.selectedId
        setScene(prev, if (prev.objects.any { it.id == sel }) sel else null)
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(_state.value.scene)
        lastEditKey = null
        val sel = _state.value.selectedId
        setScene(next, if (next.objects.any { it.id == sel }) sel else null)
    }

    // ---------- ajout / suppression ----------

    fun addShape(type: ShapeType) {
        val s = _state.value.scene
        val wide = type == ShapeType.RECTANGLE || type == ShapeType.ROUNDED_RECTANGLE
        val isLineFamily = type in LineFamily
        val isStrokeOnly = type in StrokeOnlyShapes
        // Le Polygone générique démarre à 5 côtés : sans ça, sa valeur par défaut
        // (6) le rendait visuellement identique à l'Hexagone dédié.
        val sides = if (type == ShapeType.POLYGON) 5 else 6
        val obj = LogoObject(
            id = newId(),
            kind = ObjectKind.SHAPE,
            shape = type,
            sides = sides,
            cx = s.width / 2f,
            cy = s.height / 2f,
            width = if (isLineFamily) 420f else if (wide) 360f else 300f,
            height = if (isLineFamily) 70f else if (wide) 240f else 300f,
            // Un tracé ouvert (ligne, courbe, zigzag...) n'a pas de surface à remplir :
            // sans contour visible par défaut, il serait invisible à la création.
            fillColor = if (isStrokeOnly) NO_COLOR else 0xFFD4AF37,
            strokeColor = if (isStrokeOnly) 0xFFBE8922 else 0xFF111111,
            strokeWidth = if (isStrokeOnly) 10f else 0f,
        )
        edit { it.copy(objects = it.objects + obj) }
        select(obj.id)
    }

    fun addText() {
        val s = _state.value.scene
        val base = LogoObject(
            id = newId(),
            kind = ObjectKind.TEXT,
            cx = s.width / 2f,
            cy = s.height / 2f,
            width = 100f,
            height = 100f,
            text = "Texte",
            fontSize = 140f,
            fillColor = 0xFF111111,
            bold = true,
        )
        val obj = withMetrics(base)
        edit { it.copy(objects = it.objects + obj) }
        select(obj.id)
    }

    fun duplicateSelected() {
        val sel = _state.value.selected ?: return
        val copy = sel.copy(id = newId(), cx = sel.cx + 40f, cy = sel.cy + 40f)
        edit { it.copy(objects = it.objects + copy) }
        select(copy.id)
    }

    fun deleteSelected() {
        val id = _state.value.selectedId ?: return
        edit { s -> s.copy(objects = s.objects.filter { it.id != id }) }
        select(null)
    }

    fun bringForward() = moveInStack(+1)
    fun sendBackward() = moveInStack(-1)

    private fun moveInStack(delta: Int) {
        val id = _state.value.selectedId ?: return
        val list = _state.value.scene.objects
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j !in list.indices) return
        edit { s ->
            val m = s.objects.toMutableList()
            val tmp = m[i]; m[i] = m[j]; m[j] = tmp
            s.copy(objects = m)
        }
    }

    // ---------- propriétés ----------

    fun setBackground(color: Long) = edit { it.copy(backgroundColor = color) }
    fun setFill(color: Long) = editSelected { it.copy(fillColor = color) }
    fun setStroke(color: Long) = editSelected { it.copy(strokeColor = color) }
    fun setStrokeWidth(w: Float) = editSelected("strokew") { it.copy(strokeWidth = w) }
    fun setOpacity(v: Float) = editSelected("opacity") { it.copy(opacity = v) }
    fun setSides(n: Int) = editSelected("sides") { it.copy(sides = n) }
    fun setText(t: String) = editSelected("text") { withMetrics(it.copy(text = t)) }
    fun setFontSize(v: Float) = editSelected("fontsize") { withMetrics(it.copy(fontSize = v)) }
    fun setFontFamily(f: String) = editSelected { withMetrics(it.copy(fontFamily = f)) }
    fun setBold(b: Boolean) = editSelected { withMetrics(it.copy(bold = b)) }
    fun setItalic(b: Boolean) = editSelected { withMetrics(it.copy(italic = b)) }

    // ---------- gestes sur le canevas ----------

    fun beginGesture() {
        pushUndo()
        lastEditKey = null
        _state.update { it.copy(canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty()) }
    }

    fun moveSelected(dx: Float, dy: Float) = liveUpdateSelected { it.copy(cx = it.cx + dx, cy = it.cy + dy) }

    fun resizeSelectedTo(px: Float, py: Float) = liveUpdateSelected { o ->
        val l = Geometry.toLocal(o, px, py)
        when (o.kind) {
            ObjectKind.SHAPE -> o.copy(
                width = max(24f, abs(l.x) * 2f),
                height = max(24f, abs(l.y) * 2f),
            )
            ObjectKind.TEXT -> {
                val ratio = (abs(l.x) * 2f) / max(o.width, 1f)
                withMetrics(o.copy(fontSize = (o.fontSize * ratio).coerceIn(16f, 600f)))
            }
        }
    }

    fun rotateSelectedTo(px: Float, py: Float) = liveUpdateSelected { o ->
        val deg = Math.toDegrees(atan2((py - o.cy).toDouble(), (px - o.cx).toDouble())).toFloat() + 90f
        o.copy(rotation = deg)
    }
}
