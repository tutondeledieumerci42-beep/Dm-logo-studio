package com.dmlogostudio.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Point central qui décide ce qui est Free ou Premium. Pour l'instant personne
 * n'est Premium : il n'y a pas encore de Google Play Billing branché, donc on
 * ne simule jamais un achat. Le code qui ajoutera des fonctions Premium plus
 * tard lira [isPremium] au lieu de dupliquer cette décision ailleurs.
 */
class EntitlementRepository {
    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()
}
