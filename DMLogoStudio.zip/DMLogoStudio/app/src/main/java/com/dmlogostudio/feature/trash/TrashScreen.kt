package com.dmlogostudio.feature.trash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dmlogostudio.DmLogoApp
import com.dmlogostudio.core.engine.SceneRenderer
import com.dmlogostudio.data.Project
import com.dmlogostudio.ui.theme.Gold
import com.dmlogostudio.ui.theme.Ink
import com.dmlogostudio.ui.theme.Panel
import kotlinx.coroutines.launch

/** Les projets supprimés restent ici, récupérables, tant qu'on ne les supprime pas pour de bon. */
@Composable
fun TrashScreen(onBack: () -> Unit) {
    val app = LocalContext.current.applicationContext as DmLogoApp
    val scope = rememberCoroutineScope()
    val trashed by app.repository.observeTrash().collectAsState(initial = emptyList())
    var purgeTarget by remember { mutableStateOf<Project?>(null) }

    Column(Modifier.fillMaxSize().background(Ink).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
            Text("Corbeille", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
        }

        if (trashed.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "La corbeille est vide.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(32.dp),
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                items(trashed, key = { it.id }) { project ->
                    TrashRow(
                        project = project,
                        onRestore = { scope.launch { app.repository.restore(project.id) } },
                        onDeleteForever = { purgeTarget = project },
                    )
                }
            }
        }
    }

    purgeTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { purgeTarget = null },
            title = { Text("Supprimer définitivement ?") },
            text = { Text("« ${target.name} » sera perdu pour toujours, sans possibilité de le récupérer.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { app.repository.deleteForever(target.id) }
                    purgeTarget = null
                }) { Text("Supprimer pour toujours") }
            },
            dismissButton = { TextButton(onClick = { purgeTarget = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun TrashRow(project: Project, onRestore: () -> Unit, onDeleteForever: () -> Unit) {
    val thumb = remember(project.id) { SceneRenderer.renderThumbnail(project.scene, 160).asImageBitmap() }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Panel)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            bitmap = thumb,
            contentDescription = project.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF2A2A30)),
        )
        Spacer(Modifier.height(0.dp).padding(start = 12.dp))
        Text(project.name, modifier = Modifier.weight(1f).padding(start = 12.dp), fontWeight = FontWeight.SemiBold)
        IconButton(onClick = onRestore) { Icon(Icons.Filled.Restore, contentDescription = "Restaurer", tint = Gold) }
        IconButton(onClick = onDeleteForever) {
            Icon(Icons.Filled.DeleteForever, contentDescription = "Supprimer définitivement", tint = Color(0xFFE57373))
        }
    }
}
