package com.dmlogostudio.core.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ObjectKind
import com.dmlogostudio.core.model.Scene
import kotlin.math.max
import kotlin.math.roundToInt

/** Dessine une scène sur un Canvas Android, dans l'espace de la scène (0..width, 0..height). */
object SceneRenderer {

    fun drawScene(canvas: Canvas, scene: Scene) {
        canvas.save()
        canvas.clipRect(0f, 0f, scene.width, scene.height)
        canvas.drawColor(scene.backgroundColor.toInt())
        scene.objects.forEach { drawObject(canvas, it) }
        canvas.restore()
    }

    private fun applyColor(p: Paint, color: Long, opacity: Float) {
        val c = color.toInt()
        p.color = c
        p.alpha = (Color.alpha(c) * opacity).roundToInt().coerceIn(0, 255)
    }

    private fun drawObject(canvas: Canvas, o: LogoObject) {
        canvas.save()
        canvas.translate(o.cx, o.cy)
        canvas.rotate(o.rotation)
        val fillVisible = Color.alpha(o.fillColor.toInt()) > 0
        val strokeVisible = o.strokeWidth > 0f

        when (o.kind) {
            ObjectKind.SHAPE -> {
                val path = ShapePaths.build(o)
                if (fillVisible) {
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
                    applyColor(paint, o.fillColor, o.opacity)
                    canvas.drawPath(path, paint)
                }
                if (strokeVisible) {
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        style = Paint.Style.STROKE
                        strokeWidth = o.strokeWidth
                        strokeJoin = Paint.Join.MITER
                    }
                    applyColor(paint, o.strokeColor, o.opacity)
                    canvas.drawPath(path, paint)
                }
            }
            ObjectKind.TEXT -> {
                val paint = TextMetrics.paint(o)
                val fm = paint.fontMetrics
                val baseline = -(fm.ascent + fm.descent) / 2f
                if (fillVisible) {
                    paint.style = Paint.Style.FILL
                    applyColor(paint, o.fillColor, o.opacity)
                    canvas.drawText(o.text, 0f, baseline, paint)
                }
                if (strokeVisible) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = o.strokeWidth
                    applyColor(paint, o.strokeColor, o.opacity)
                    canvas.drawText(o.text, 0f, baseline, paint)
                }
            }
        }
        canvas.restore()
    }

    /** Miniature d'un projet (utilisée dans « Mes créations »). */
    fun renderThumbnail(scene: Scene, maxSide: Int = 360): Bitmap {
        val scale = maxSide / max(scene.width, scene.height)
        val w = max(1, (scene.width * scale).roundToInt())
        val h = max(1, (scene.height * scale).roundToInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(scale, scale)
        drawScene(c, scene)
        return bmp
    }
}
