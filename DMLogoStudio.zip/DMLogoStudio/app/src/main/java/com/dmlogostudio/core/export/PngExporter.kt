package com.dmlogostudio.core.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.dmlogostudio.core.engine.SceneRenderer
import com.dmlogostudio.core.model.Scene
import kotlin.math.max
import kotlin.math.roundToInt

object PngExporter {
    private const val TARGET_LONG_SIDE = 2048f

    /**
     * Rend la scène en PNG plein format et l'enregistre dans Pictures/DM Logo Studio,
     * via MediaStore (aucune permission requise sur Android 10 et plus).
     * Retourne l'Uri du fichier créé, ou null si l'enregistrement a échoué.
     */
    fun export(context: Context, scene: Scene, projectName: String): Uri? {
        val longSide = max(scene.width, scene.height).coerceAtLeast(1f)
        val scale = TARGET_LONG_SIDE / longSide
        val w = max(1, (scene.width * scale).roundToInt())
        val h = max(1, (scene.height * scale).roundToInt())

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.scale(scale, scale)
        SceneRenderer.drawScene(canvas, scene)

        val safeName = projectName.trim()
            .ifBlank { "logo" }
            .replace(Regex("[^A-Za-z0-9 _-]"), "")
            .ifBlank { "logo" }
        val fileName = "$safeName-${System.currentTimeMillis()}.png"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DM Logo Studio")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        return try {
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            val wrote = resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            } ?: false
            if (!wrote) return null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            uri
        } catch (e: Exception) {
            null
        } finally {
            bitmap.recycle()
        }
    }
}
