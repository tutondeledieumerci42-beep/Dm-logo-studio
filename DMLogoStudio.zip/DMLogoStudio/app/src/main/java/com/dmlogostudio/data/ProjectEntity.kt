package com.dmlogostudio.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val sceneJson: String,
    /** Null = projet actif. Sinon, date de mise à la corbeille : le projet
     *  est caché de la liste principale mais pas encore supprimé pour de bon. */
    val deletedAt: Long? = null,
)
