package com.dmlogostudio.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dmlogostudio.feature.editor.EditorScreen
import com.dmlogostudio.feature.home.HomeScreen
import com.dmlogostudio.feature.settings.SettingsScreen
import com.dmlogostudio.feature.templates.TemplatesScreen
import com.dmlogostudio.ui.theme.Gold
import com.dmlogostudio.ui.theme.Ink

private const val ROUTE_HOME = "home"
private const val ROUTE_TEMPLATES = "templates"
private const val ROUTE_SETTINGS = "settings"

private data class BottomDestination(val route: String, val label: String, val icon: @Composable () -> Unit)

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    // La barre du bas n'apparaît que sur les trois écrans principaux, jamais dans l'éditeur.
    val showBottomBar = currentRoute == ROUTE_HOME || currentRoute == ROUTE_TEMPLATES || currentRoute == ROUTE_SETTINGS

    Scaffold(
        containerColor = Ink,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = Ink, tonalElevation = 0.dp) {
                    val destinations = listOf(
                        BottomDestination(ROUTE_HOME, "Tableau de Bord") { Icon(Icons.Filled.Home, contentDescription = null) },
                        BottomDestination(ROUTE_TEMPLATES, "Modèles") { Icon(Icons.Filled.GridView, contentDescription = null) },
                        BottomDestination(ROUTE_SETTINGS, "Paramètres") { Icon(Icons.Filled.Settings, contentDescription = null) },
                    )
                    destinations.forEach { dest ->
                        val selected = backStackEntry?.destination?.hierarchy?.any { it.route == dest.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (!selected) {
                                    nav.navigate(dest.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = dest.icon,
                            label = { Text(dest.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold,
                                selectedTextColor = Gold,
                                indicatorColor = Ink,
                            ),
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = nav,
            startDestination = ROUTE_HOME,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(ROUTE_HOME) {
                HomeScreen(onOpenProject = { id -> nav.navigate("editor/$id") })
            }
            composable(ROUTE_TEMPLATES) { TemplatesScreen() }
            composable(ROUTE_SETTINGS) { SettingsScreen() }
            composable(
                route = "editor/{projectId}",
                arguments = listOf(navArgument("projectId") { type = NavType.StringType }),
            ) { entry ->
                val id = entry.arguments?.getString("projectId").orEmpty()
                EditorScreen(projectId = id, onBack = { nav.popBackStack() })
            }
        }
    }
}
