package com.dmlogostudio.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dmlogostudio.feature.editor.EditorScreen
import com.dmlogostudio.feature.home.HomeScreen

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(onOpenProject = { id -> nav.navigate("editor/$id") })
        }
        composable(
            route = "editor/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType }),
        ) { entry ->
            val id = entry.arguments?.getString("projectId").orEmpty()
            EditorScreen(projectId = id, onBack = { nav.popBackStack() })
        }
    }
}
