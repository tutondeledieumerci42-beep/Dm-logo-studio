package com.dmlogostudio.core.engine

import android.graphics.Path
import android.graphics.RectF
import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ShapeType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object ShapePaths {
    /** Construit le tracé de la forme centré sur (0,0), sans rotation. */
    fun build(o: LogoObject): Path {
        val hw = o.width / 2f
        val hh = o.height / 2f
        val p = Path()
        when (o.shape) {
            ShapeType.RECTANGLE -> p.addRect(-hw, -hh, hw, hh, Path.Direction.CW)
            ShapeType.ROUNDED_RECTANGLE -> {
                val r = min(o.width, o.height) * 0.2f
                p.addRoundRect(RectF(-hw, -hh, hw, hh), r, r, Path.Direction.CW)
            }
            ShapeType.ELLIPSE -> p.addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW)
            ShapeType.TRIANGLE -> {
                p.moveTo(0f, -hh)
                p.lineTo(hw, hh)
                p.lineTo(-hw, hh)
                p.close()
            }
            ShapeType.STAR -> buildStar(p, hw, hh, points = 5, innerRatio = 0.42f)
            ShapeType.POLYGON -> buildRegularPolygon(p, hw, hh, o.sides.coerceIn(3, 12))
            ShapeType.HEXAGON -> buildRegularPolygon(p, hw, hh, 6)
            ShapeType.OCTAGON -> buildRegularPolygon(p, hw, hh, 8)
            ShapeType.DIAMOND -> buildRegularPolygon(p, hw, hh, 4)
            ShapeType.CROSS -> buildCross(p, hw, hh)
            ShapeType.HEART -> buildHeart(p, hw, hh)
            ShapeType.RING -> return buildRing(hw, hh)
            ShapeType.SEMICIRCLE -> buildSemicircle(p, hw, hh)
            ShapeType.TRAPEZOID -> buildTrapezoid(p, hw, hh)
            ShapeType.PARALLELOGRAM -> buildParallelogram(p, hw, hh)
            ShapeType.CRESCENT -> return buildCrescent(hw, hh)
        }
        return p
    }

    private fun buildRegularPolygon(p: Path, hw: Float, hh: Float, sides: Int) {
        for (i in 0 until sides) {
            val a = -PI / 2 + i * 2 * PI / sides
            val x = (cos(a) * hw).toFloat()
            val y = (sin(a) * hh).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun buildStar(p: Path, hw: Float, hh: Float, points: Int, innerRatio: Float) {
        val total = points * 2
        for (i in 0 until total) {
            val a = -PI / 2 + i * PI / points
            val k = if (i % 2 == 0) 1f else innerRatio
            val x = (cos(a) * k * hw).toFloat()
            val y = (sin(a) * k * hh).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun buildCross(p: Path, hw: Float, hh: Float) {
        val tx = hw * 0.38f // demi-épaisseur horizontale de la barre verticale
        val ty = hh * 0.38f // demi-épaisseur verticale de la barre horizontale
        p.moveTo(-tx, -hh)
        p.lineTo(tx, -hh)
        p.lineTo(tx, -ty)
        p.lineTo(hw, -ty)
        p.lineTo(hw, ty)
        p.lineTo(tx, ty)
        p.lineTo(tx, hh)
        p.lineTo(-tx, hh)
        p.lineTo(-tx, ty)
        p.lineTo(-hw, ty)
        p.lineTo(-hw, -ty)
        p.lineTo(-tx, -ty)
        p.close()
    }

    private fun buildHeart(p: Path, hw: Float, hh: Float) {
        // Cœur paramétrique construit avec deux courbes de Bézier symétriques.
        p.moveTo(0f, hh)
        p.cubicTo(-hw * 1.3f, hh * 0.1f, -hw * 0.9f, -hh * 0.9f, 0f, -hh * 0.35f)
        p.cubicTo(hw * 0.9f, -hh * 0.9f, hw * 1.3f, hh * 0.1f, 0f, hh)
        p.close()
    }

    private fun buildSemicircle(p: Path, hw: Float, hh: Float) {
        val oval = RectF(-hw, -hh * 2, hw, 0f)
        p.moveTo(-hw, 0f)
        p.arcTo(oval, 180f, 180f, false)
        p.lineTo(-hw, 0f)
        p.close()
    }

    private fun buildTrapezoid(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw * 0.55f, -hh)
        p.lineTo(hw * 0.55f, -hh)
        p.lineTo(hw, hh)
        p.lineTo(-hw, hh)
        p.close()
    }

    private fun buildParallelogram(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw * 0.55f, -hh)
        p.lineTo(hw, -hh)
        p.lineTo(hw * 0.55f, hh)
        p.lineTo(-hw, hh)
        p.close()
    }

    private fun buildRing(hw: Float, hh: Float): Path {
        val outer = Path().apply { addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW) }
        val inner = Path().apply {
            val ir = 0.55f
            addOval(RectF(-hw * ir, -hh * ir, hw * ir, hh * ir), Path.Direction.CW)
        }
        val result = Path()
        result.op(outer, inner, Path.Op.DIFFERENCE)
        return result
    }

    private fun buildCrescent(hw: Float, hh: Float): Path {
        val main = Path().apply { addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW) }
        val bite = Path().apply {
            val offsetX = hw * 0.55f
            addOval(RectF(-hw * 0.9f + offsetX, -hh * 0.9f, hw * 0.9f + offsetX, hh * 0.9f), Path.Direction.CW)
        }
        val result = Path()
        result.op(main, bite, Path.Op.DIFFERENCE)
        return result
    }
}
