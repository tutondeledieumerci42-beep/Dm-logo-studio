package com.dmlogostudio.core.engine

import android.graphics.Path
import android.graphics.RectF
import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ShapeType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object ShapePaths {
    /** Construit le tracé de la forme centré sur (0,0), sans rotation. */
    fun build(o: LogoObject): Path {
        val hw = o.width / 2f
        val hh = o.height / 2f
        val p = Path()
        when (o.shape) {
            ShapeType.RECTANGLE -> p.addRect(-hw, -hh, hw, hh, Path.Direction.CW)
            ShapeType.ROUNDED_RECTANGLE -> {
                val r = min(o.width, o.height) * 0.2f
                p.addRoundRect(RectF(-hw, -hh, hw, hh), r, r, Path.Direction.CW)
            }
            ShapeType.ELLIPSE -> p.addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW)
            ShapeType.TRIANGLE -> {
                p.moveTo(0f, -hh)
                p.lineTo(hw, hh)
                p.lineTo(-hw, hh)
                p.close()
            }
            ShapeType.STAR -> buildStar(p, hw, hh, points = 5, innerRatio = 0.42f)
            ShapeType.POLYGON -> buildRegularPolygon(p, hw, hh, o.sides.coerceIn(3, 12))
            ShapeType.HEXAGON -> buildRegularPolygon(p, hw, hh, 6)
            ShapeType.OCTAGON -> buildRegularPolygon(p, hw, hh, 8)
            ShapeType.DIAMOND -> buildRegularPolygon(p, hw, hh, 4)
            ShapeType.CROSS -> buildCross(p, hw, hh)
            ShapeType.HEART -> buildHeart(p, hw, hh)
            ShapeType.RING -> return buildRing(hw, hh)
            ShapeType.SEMICIRCLE -> buildSemicircle(p, hw, hh)
            ShapeType.TRAPEZOID -> buildTrapezoid(p, hw, hh)
            ShapeType.PARALLELOGRAM -> buildParallelogram(p, hw, hh)
            ShapeType.CRESCENT -> return buildCrescent(hw, hh)
            ShapeType.ARC -> buildArc(p, hw, hh)
            ShapeType.RIGHT_TRIANGLE -> buildRightTriangle(p, hw, hh)
            ShapeType.LINE -> {
                p.moveTo(-hw, 0f)
                p.lineTo(hw, 0f)
            }
            ShapeType.ARROW -> buildArrow(p, hw, hh, doubleHeaded = false)
            ShapeType.DOUBLE_ARROW -> buildArrow(p, hw, hh, doubleHeaded = true)
            ShapeType.DASHED_LINE -> {
                p.moveTo(-hw, 0f)
                p.lineTo(hw, 0f)
            }
            ShapeType.CURVE -> {
                p.moveTo(-hw, 0f)
                p.quadTo(0f, -hh, hw, 0f)
            }
            ShapeType.ZIGZAG -> buildZigzag(p, hw, hh)
            ShapeType.WAVE -> buildWave(p, hw, hh)
            ShapeType.CURVED_ARROW -> buildCurvedArrow(p, hw, hh)
            ShapeType.FREEHAND -> buildFreehand(p, hw, hh, o.freehandPoints)
        }
        return p
    }

    private fun buildRegularPolygon(p: Path, hw: Float, hh: Float, sides: Int) {
        for (i in 0 until sides) {
            val a = -PI / 2 + i * 2 * PI / sides
            val x = (cos(a) * hw).toFloat()
            val y = (sin(a) * hh).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun buildStar(p: Path, hw: Float, hh: Float, points: Int, innerRatio: Float) {
        val total = points * 2
        for (i in 0 until total) {
            val a = -PI / 2 + i * PI / points
            val k = if (i % 2 == 0) 1f else innerRatio
            val x = (cos(a) * k * hw).toFloat()
            val y = (sin(a) * k * hh).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun buildCross(p: Path, hw: Float, hh: Float) {
        val tx = hw * 0.38f // demi-épaisseur horizontale de la barre verticale
        val ty = hh * 0.38f // demi-épaisseur verticale de la barre horizontale
        p.moveTo(-tx, -hh)
        p.lineTo(tx, -hh)
        p.lineTo(tx, -ty)
        p.lineTo(hw, -ty)
        p.lineTo(hw, ty)
        p.lineTo(tx, ty)
        p.lineTo(tx, hh)
        p.lineTo(-tx, hh)
        p.lineTo(-tx, ty)
        p.lineTo(-hw, ty)
        p.lineTo(-hw, -ty)
        p.lineTo(-tx, -ty)
        p.close()
    }

    private fun buildHeart(p: Path, hw: Float, hh: Float) {
        // Cœur paramétrique construit avec deux courbes de Bézier symétriques.
        p.moveTo(0f, hh)
        p.cubicTo(-hw * 1.3f, hh * 0.1f, -hw * 0.9f, -hh * 0.9f, 0f, -hh * 0.35f)
        p.cubicTo(hw * 0.9f, -hh * 0.9f, hw * 1.3f, hh * 0.1f, 0f, hh)
        p.close()
    }

    private fun buildSemicircle(p: Path, hw: Float, hh: Float) {
        // Cercle complet dont seule la moitié haute est tracée : base plate en
        // bas du cadre (y = hh), sommet du dôme en haut du cadre (y = -hh).
        val oval = RectF(-hw, -hh, hw, 3 * hh)
        p.moveTo(-hw, hh)
        p.arcTo(oval, 180f, 180f, false)
        p.lineTo(-hw, hh)
        p.close()
    }

    private fun buildTrapezoid(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw * 0.55f, -hh)
        p.lineTo(hw * 0.55f, -hh)
        p.lineTo(hw, hh)
        p.lineTo(-hw, hh)
        p.close()
    }

    private fun buildParallelogram(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw * 0.55f, -hh)
        p.lineTo(hw, -hh)
        p.lineTo(hw * 0.55f, hh)
        p.lineTo(-hw, hh)
        p.close()
    }

    /** Un épais arc de cercle de 270°, en forme de "C", comme un anneau ouvert. */
    private fun buildArc(p: Path, hw: Float, hh: Float) {
        val outer = RectF(-hw, -hh, hw, hh)
        val innerRatio = 0.55f
        val inner = RectF(-hw * innerRatio, -hh * innerRatio, hw * innerRatio, hh * innerRatio)
        val sweep = 270f
        val start = 90f // l'ouverture du "C" pointe vers le haut
        p.arcTo(outer, start, sweep, true)
        p.arcTo(inner, start + sweep, -sweep, false)
        p.close()
    }

    /** Triangle rectangle : la forme géométrique asymétrique demandée, avec l'angle
     *  droit dans le coin inférieur gauche plutôt qu'un sommet centré. */
    private fun buildRightTriangle(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw, hh)
        p.lineTo(-hw, -hh)
        p.lineTo(hw, hh)
        p.close()
    }

    /** Flèche horizontale (pointe vers +x) pouvant être tournée via la poignée de
     *  rotation habituelle. [doubleHeaded] ajoute une seconde pointe à gauche. */
    private fun buildArrow(p: Path, hw: Float, hh: Float, doubleHeaded: Boolean) {
        val shaftH = hh * 0.25f
        val headLen = (hw * 0.45f).coerceAtMost(hh * 1.4f)
        val headH = hh
        if (doubleHeaded) {
            p.moveTo(-hw, 0f)
            p.lineTo(-hw + headLen, -headH)
            p.lineTo(-hw + headLen, -shaftH)
            p.lineTo(hw - headLen, -shaftH)
            p.lineTo(hw - headLen, -headH)
            p.lineTo(hw, 0f)
            p.lineTo(hw - headLen, headH)
            p.lineTo(hw - headLen, shaftH)
            p.lineTo(-hw + headLen, shaftH)
            p.lineTo(-hw + headLen, headH)
        } else {
            p.moveTo(-hw, -shaftH)
            p.lineTo(hw - headLen, -shaftH)
            p.lineTo(hw - headLen, -headH)
            p.lineTo(hw, 0f)
            p.lineTo(hw - headLen, headH)
            p.lineTo(hw - headLen, shaftH)
            p.lineTo(-hw, shaftH)
        }
        p.close()
    }

    private fun buildZigzag(p: Path, hw: Float, hh: Float) {
        val segments = 4
        p.moveTo(-hw, 0f)
        for (i in 1..segments) {
            val x = -hw + (2 * hw) * i / segments
            val y = if (i % 2 == 1) -hh else hh
            p.lineTo(x, y)
        }
    }

    private fun buildWave(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw, 0f)
        p.cubicTo(-hw * 0.5f, -hh, 0f, -hh, 0f, 0f)
        p.cubicTo(hw * 0.5f, hh, hw * 0.5f, hh, hw, 0f)
    }

    private fun buildCurvedArrow(p: Path, hw: Float, hh: Float) {
        p.moveTo(-hw, 0f)
        p.quadTo(0f, -hh, hw, 0f)
        // Chevron à la pointe, orienté selon la tangente réelle de la courbe à son extrémité.
        val dx = hw
        val dy = hh
        val len = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(0.001f)
        val ux = dx / len
        val uy = dy / len
        val perpX = -uy
        val perpY = ux
        val headLen = min(hw, hh) * 0.55f
        p.moveTo(hw - ux * headLen + perpX * headLen * 0.6f, 0f - uy * headLen + perpY * headLen * 0.6f)
        p.lineTo(hw, 0f)
        p.lineTo(hw - ux * headLen - perpX * headLen * 0.6f, 0f - uy * headLen - perpY * headLen * 0.6f)
    }

    /** Rejoue un tracé dessiné au doigt : les points sont stockés normalisés
     *  (-1..1), donc il suffit de les multiplier par la taille actuelle. */
    private fun buildFreehand(p: Path, hw: Float, hh: Float, points: List<com.dmlogostudio.core.model.FreehandPoint>) {
        if (points.isEmpty()) return
        val first = points[0]
        p.moveTo(first.x * hw, first.y * hh)
        for (i in 1 until points.size) {
            val pt = points[i]
            p.lineTo(pt.x * hw, pt.y * hh)
        }
    }

    private fun buildRing(hw: Float, hh: Float): Path {
        val outer = Path().apply { addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW) }
        val inner = Path().apply {
            val ir = 0.55f
            addOval(RectF(-hw * ir, -hh * ir, hw * ir, hh * ir), Path.Direction.CW)
        }
        val result = Path()
        result.op(outer, inner, Path.Op.DIFFERENCE)
        return result
    }

    private fun buildCrescent(hw: Float, hh: Float): Path {
        val main = Path().apply { addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW) }
        val bite = Path().apply {
            val offsetX = hw * 0.55f
            addOval(RectF(-hw * 0.9f + offsetX, -hh * 0.9f, hw * 0.9f + offsetX, hh * 0.9f), Path.Direction.CW)
        }
        val result = Path()
        result.op(main, bite, Path.Op.DIFFERENCE)
        return result
    }
}
