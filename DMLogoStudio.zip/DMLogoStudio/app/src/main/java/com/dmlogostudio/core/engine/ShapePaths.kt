package com.dmlogostudio.core.engine

import android.graphics.Path
import android.graphics.RectF
import com.dmlogostudio.core.model.LogoObject
import com.dmlogostudio.core.model.ShapeType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object ShapePaths {
    /** Construit le tracé de la forme centré sur (0,0), sans rotation. */
    fun build(o: LogoObject): Path {
        val hw = o.width / 2f
        val hh = o.height / 2f
        val p = Path()
        when (o.shape) {
            ShapeType.RECTANGLE -> p.addRect(-hw, -hh, hw, hh, Path.Direction.CW)
            ShapeType.ROUNDED_RECTANGLE -> {
                val r = min(o.width, o.height) * 0.2f
                p.addRoundRect(RectF(-hw, -hh, hw, hh), r, r, Path.Direction.CW)
            }
            ShapeType.ELLIPSE -> p.addOval(RectF(-hw, -hh, hw, hh), Path.Direction.CW)
            ShapeType.TRIANGLE -> {
                p.moveTo(0f, -hh)
                p.lineTo(hw, hh)
                p.lineTo(-hw, hh)
                p.close()
            }
            ShapeType.STAR -> {
                for (i in 0 until 10) {
                    val a = -PI / 2 + i * PI / 5
                    val k = if (i % 2 == 0) 1f else 0.42f
                    val x = (cos(a) * k * hw).toFloat()
                    val y = (sin(a) * k * hh).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            ShapeType.POLYGON -> {
                val n = o.sides.coerceIn(3, 12)
                for (i in 0 until n) {
                    val a = -PI / 2 + i * 2 * PI / n
                    val x = (cos(a) * hw).toFloat()
                    val y = (sin(a) * hh).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
        }
        return p
    }
}
