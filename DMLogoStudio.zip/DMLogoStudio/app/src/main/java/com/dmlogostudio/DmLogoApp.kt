package com.dmlogostudio

import android.app.Application
import androidx.room.Room
import com.dmlogostudio.data.AppDatabase
import com.dmlogostudio.data.ProjectRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class DmLogoApp : Application() {
    lateinit var repository: ProjectRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = Room.databaseBuilder(this, AppDatabase::class.java, "dm_logo_studio.db").build()
        repository = ProjectRepository(db.projectDao(), CoroutineScope(SupervisorJob() + Dispatchers.IO))
    }
}
