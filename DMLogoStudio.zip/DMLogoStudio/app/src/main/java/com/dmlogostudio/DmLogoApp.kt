package com.dmlogostudio

import android.app.Application
import androidx.room.Room
import com.dmlogostudio.data.AppDatabase
import com.dmlogostudio.data.EntitlementRepository
import com.dmlogostudio.data.ProjectRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class DmLogoApp : Application() {
    lateinit var repository: ProjectRepository
        private set
    val entitlements = EntitlementRepository()

    override fun onCreate() {
        super.onCreate()
        val db = Room.databaseBuilder(this, AppDatabase::class.java, "dm_logo_studio.db")
            // Le projet est encore en phase de test : pas de vraie migration écrite pour
            // l'instant entre les versions de la base. À remplacer par une Migration()
            // réelle avant publication, pour ne jamais effacer les projets des utilisateurs.
            .fallbackToDestructiveMigration()
            .build()
        repository = ProjectRepository(db.projectDao(), CoroutineScope(SupervisorJob() + Dispatchers.IO))
    }
}
