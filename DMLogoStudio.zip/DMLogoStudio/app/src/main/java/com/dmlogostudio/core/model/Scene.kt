package com.dmlogostudio.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class ObjectKind { SHAPE, TEXT }

@Serializable
enum class ShapeType {
    RECTANGLE, ROUNDED_RECTANGLE, ELLIPSE, TRIANGLE, STAR, POLYGON,
    HEXAGON, OCTAGON, DIAMOND, CROSS, HEART, RING, SEMICIRCLE, TRAPEZOID, PARALLELOGRAM, CRESCENT,
    ARC, RIGHT_TRIANGLE,
    LINE, ARROW, DOUBLE_ARROW,
}

/**
 * Un objet du logo (forme ou texte). Les couleurs sont stockées en ARGB dans un Long.
 * (cx, cy) = centre dans l'espace de la scène, width/height = taille avant rotation.
 */
@Serializable
data class LogoObject(
    val id: String,
    val kind: ObjectKind,
    val shape: ShapeType = ShapeType.RECTANGLE,
    val sides: Int = 6,
    val cx: Float,
    val cy: Float,
    val width: Float,
    val height: Float,
    val rotation: Float = 0f,
    val fillColor: Long = 0xFFD4AF37,
    val strokeColor: Long = 0xFF111111,
    val strokeWidth: Float = 0f,
    val opacity: Float = 1f,
    val text: String = "",
    val fontSize: Float = 120f,
    val fontFamily: String = "sans-serif",
    val bold: Boolean = false,
    val italic: Boolean = false,
)

/** Le document : une planche et la liste ordonnée des objets (le dernier est au premier plan). */
@Serializable
data class Scene(
    val width: Float = 1000f,
    val height: Float = 1000f,
    val backgroundColor: Long = 0xFFFFFFFF,
    val objects: List<LogoObject> = emptyList(),
)
