package com.dmlogostudio.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class ObjectKind { SHAPE, TEXT }

@Serializable
enum class ShapeType {
    RECTANGLE, ROUNDED_RECTANGLE, ELLIPSE, TRIANGLE, STAR, POLYGON,
    HEXAGON, OCTAGON, DIAMOND, CROSS, HEART, RING, SEMICIRCLE, TRAPEZOID, PARALLELOGRAM, CRESCENT,
    ARC, RIGHT_TRIANGLE,
    LINE, ARROW, DOUBLE_ARROW,
    DASHED_LINE, CURVE, ZIGZAG, WAVE, CURVED_ARROW,
    FREEHAND,
}

/** Vrai pour les tracés ouverts (ligne, flèche, dessin libre...) : contrairement
 *  aux formes pleines, on ne doit pouvoir les sélectionner qu'en touchant le
 *  trait lui-même, pas n'importe où dans son grand cadre englobant. */
fun ShapeType.isOpenPath(): Boolean = this == ShapeType.LINE ||
    this == ShapeType.DASHED_LINE || this == ShapeType.CURVE || this == ShapeType.ZIGZAG ||
    this == ShapeType.WAVE || this == ShapeType.ARROW || this == ShapeType.DOUBLE_ARROW ||
    this == ShapeType.CURVED_ARROW || this == ShapeType.FREEHAND

/** Un point d'un tracé à main levée, normalisé entre -1 et 1 par rapport au
 *  centre de l'objet au moment du dessin : multiplié par la demi-largeur et
 *  la demi-hauteur actuelles au rendu, ce qui fait que le redimensionnement
 *  déjà existant du projet fonctionne pour ces tracés sans code spécial. */
@Serializable
data class FreehandPoint(val x: Float, val y: Float)

/**
 * Un objet du logo (forme ou texte). Les couleurs sont stockées en ARGB dans un Long.
 * (cx, cy) = centre dans l'espace de la scène, width/height = taille avant rotation.
 */
@Serializable
data class LogoObject(
    val id: String,
    val kind: ObjectKind,
    val shape: ShapeType = ShapeType.RECTANGLE,
    val sides: Int = 6,
    val cx: Float,
    val cy: Float,
    val width: Float,
    val height: Float,
    val rotation: Float = 0f,
    val fillColor: Long = 0xFFD4AF37,
    val strokeColor: Long = 0xFF111111,
    val strokeWidth: Float = 0f,
    val opacity: Float = 1f,
    val text: String = "",
    val fontSize: Float = 120f,
    val fontFamily: String = "sans-serif",
    val bold: Boolean = false,
    val italic: Boolean = false,
    val freehandPoints: List<FreehandPoint> = emptyList(),
)

/** Le document : une planche et la liste ordonnée des objets (le dernier est au premier plan). */
@Serializable
data class Scene(
    val width: Float = 1000f,
    val height: Float = 1000f,
    val backgroundColor: Long = 0xFFFFFFFF,
    val objects: List<LogoObject> = emptyList(),
)
