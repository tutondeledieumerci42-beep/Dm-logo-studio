package com.dmlogostudio.feature.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.dmlogostudio.DmLogoApp
import com.dmlogostudio.R
import com.dmlogostudio.core.engine.SceneRenderer
import com.dmlogostudio.data.Project
import com.dmlogostudio.data.ProjectRepository
import com.dmlogostudio.ui.theme.Gold
import com.dmlogostudio.ui.theme.GoldSoft
import com.dmlogostudio.ui.theme.Ink
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class HomeViewModel(private val repo: ProjectRepository) : ViewModel() {
    val projects: StateFlow<List<Project>> = repo.observeProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun create(name: String, onCreated: (String) -> Unit) {
        viewModelScope.launch { onCreated(repo.create(name)) }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch { repo.rename(id, name) }
    }

    fun duplicate(id: String) {
        viewModelScope.launch { repo.duplicate(id) }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }
}

// Fractions mesurées sur l'image de fond pour caler les vraies zones cliquables
// et la vraie liste de projets exactement sur le bouton et la zone dessinés.
private const val BUTTON_TOP_FRACTION = 0.186f
private const val BUTTON_BOTTOM_FRACTION = 0.255f

@Composable
fun HomeScreen(onOpenProject: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as DmLogoApp
    val vm: HomeViewModel = viewModel(factory = viewModelFactory {
        initializer { HomeViewModel(app.repository) }
    })
    val projects by vm.projects.collectAsState()

    var showNew by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Project?>(null) }
    var deleteTarget by remember { mutableStateOf<Project?>(null) }

    val hasProjects = projects.isNotEmpty()

    Box(
        Modifier
            .fillMaxSize()
            // L'image bg_home_top se fond elle-même en dégradé jusqu'au noir exact
            // de ce fond : plus de ligne de jonction visible, quelle que soit la
            // taille de l'écran.
            .background(Ink),
    ) {
        // Fond fixe choisi par l'utilisateur, intégré au code de l'appli.
        Image(
            painter = painterResource(if (hasProjects) R.drawable.bg_home_top else R.drawable.bg_home),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier
                .fillMaxWidth()
                .let { if (hasProjects) it else it.fillMaxSize() },
        )

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val screenHeight = maxHeight

            // Zone invisible cliquable, calée sur le bouton doré dessiné dans l'image.
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(y = screenHeight * BUTTON_TOP_FRACTION)
                    .fillMaxWidth()
                    .height(screenHeight * (BUTTON_BOTTOM_FRACTION - BUTTON_TOP_FRACTION))
                    .clickable { showNew = true },
            ) {
                SparkleOverlay(Modifier.fillMaxSize())
            }

            // Quand il y a des projets, on dessine nous-mêmes "Mes créations" et la
            // grille, sur le fond sans texte baked, pour ne jamais superposer deux textes.
            if (hasProjects) {
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(y = screenHeight * (BUTTON_BOTTOM_FRACTION + 0.03f))
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                ) {
                    Text("Mes créations", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                    Spacer(Modifier.height(12.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth().height(screenHeight * 0.6f),
                    ) {
                        items(projects, key = { it.id }) { project ->
                            ProjectCard(
                                project = project,
                                onOpen = { onOpenProject(project.id) },
                                onRename = { renameTarget = project },
                                onDuplicate = { vm.duplicate(project.id) },
                                onDelete = { deleteTarget = project },
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        NameDialog(
            title = "Nouveau projet",
            initial = "Mon logo",
            confirmLabel = "Créer",
            onConfirm = { name ->
                showNew = false
                vm.create(name, onOpenProject)
            },
            onDismiss = { showNew = false },
        )
    }
    renameTarget?.let { target ->
        NameDialog(
            title = "Renommer",
            initial = target.name,
            confirmLabel = "Enregistrer",
            onConfirm = { name ->
                vm.rename(target.id, name)
                renameTarget = null
            },
            onDismiss = { renameTarget = null },
        )
    }
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Supprimer ce projet ?") },
            text = { Text("« ${target.name} » sera supprimé définitivement.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(target.id)
                    deleteTarget = null
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Annuler") } },
        )
    }
}

/** Petites particules qui scintillent doucement sur le bouton doré. */
@Composable
private fun SparkleOverlay(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "sparkle")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "sparklePhase",
    )
    val sparkles = remember {
        val rnd = Random(7)
        List(6) { Offset(rnd.nextFloat(), rnd.nextFloat()) }
    }
    Canvas(modifier) {
        sparkles.forEachIndexed { i, pos ->
            val twinkle = (sin(phase + i * 1.3f) + 1f) / 2f
            val alpha = 0.15f + twinkle * 0.45f
            val cx = size.width * (0.1f + pos.x * 0.8f)
            val cy = size.height * (0.2f + pos.y * 0.6f)
            val r = size.height * (0.06f + 0.05f * twinkle)
            drawSparkle(cx, cy, r, Color.White.copy(alpha = alpha))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSparkle(cx: Float, cy: Float, r: Float, color: Color) {
    val path = androidx.compose.ui.graphics.Path()
    for (i in 0 until 4) {
        val angle = (Math.PI / 2 * i).toFloat()
        val outerX = cx + cos(angle) * r
        val outerY = cy + sin(angle) * r
        val innerAngle = angle + (Math.PI / 4).toFloat()
        val innerX = cx + cos(innerAngle) * (r * 0.35f)
        val innerY = cy + sin(innerAngle) * (r * 0.35f)
        if (i == 0) path.moveTo(outerX, outerY) else path.lineTo(outerX, outerY)
        path.lineTo(innerX, innerY)
    }
    path.close()
    drawPath(path, color)
}

@Composable
private fun ProjectCard(
    project: Project,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    val thumb = remember(project.id, project.updatedAt) {
        SceneRenderer.renderThumbnail(project.scene, 360).asImageBitmap()
    }
    val date = remember(project.updatedAt) {
        DateFormat.getDateInstance(DateFormat.SHORT).format(Date(project.updatedAt))
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1D22)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.4f)),
    ) {
        // Liseré doré en haut de carte pour un rendu plus premium.
        Box(
            Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(Brush.horizontalGradient(listOf(GoldSoft, Gold, GoldSoft))),
        )
        Box(Modifier.clickable(onClick = onOpen)) {
            Image(
                bitmap = thumb,
                contentDescription = project.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(Color(0xFF2A2A30)),
            )
        }
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(project.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(date, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                Text(
                    "Éditer",
                    color = Gold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable(onClick = onOpen),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Renommer",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    modifier = Modifier.clickable(onClick = onRename),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Dupliquer",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    modifier = Modifier.clickable(onClick = onDuplicate),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Supprimer",
                    color = Color(0xFFE57373),
                    fontSize = 11.sp,
                    modifier = Modifier.clickable(onClick = onDelete),
                )
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                label = { Text("Nom du projet") },
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
