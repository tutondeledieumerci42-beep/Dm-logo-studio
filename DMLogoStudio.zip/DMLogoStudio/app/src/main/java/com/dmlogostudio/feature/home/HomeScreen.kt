package com.dmlogostudio.feature.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.dmlogostudio.DmLogoApp
import com.dmlogostudio.R
import com.dmlogostudio.core.engine.SceneRenderer
import com.dmlogostudio.data.Project
import com.dmlogostudio.data.ProjectRepository
import com.dmlogostudio.ui.theme.Gold
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class HomeViewModel(private val repo: ProjectRepository) : ViewModel() {
    val projects: StateFlow<List<Project>> = repo.observeProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun create(name: String, onCreated: (String) -> Unit) {
        viewModelScope.launch { onCreated(repo.create(name)) }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch { repo.rename(id, name) }
    }

    fun duplicate(id: String) {
        viewModelScope.launch { repo.duplicate(id) }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }
}

// Positions du bouton "Nouveau projet" et de la zone "Mes créations" dans l'image
// de fond (fractions mesurées sur l'image bg_home.png), pour placer les vraies
// zones cliquables et la vraie liste de projets au bon endroit par-dessus l'image.
private const val BUTTON_TOP_FRACTION = 0.169f
private const val BUTTON_BOTTOM_FRACTION = 0.232f
private const val CREATIONS_TOP_FRACTION = 0.335f

@Composable
fun HomeScreen(onOpenProject: (String) -> Unit) {
    val app = LocalContext.current.applicationContext as DmLogoApp
    val vm: HomeViewModel = viewModel(factory = viewModelFactory {
        initializer { HomeViewModel(app.repository) }
    })
    val projects by vm.projects.collectAsState()

    var showNew by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Project?>(null) }
    var deleteTarget by remember { mutableStateOf<Project?>(null) }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding(),
    ) {
        // Fond fixe choisi par l'utilisateur : fait partie du code de l'appli,
        // personne ne peut le changer sans une nouvelle version.
        Image(
            painter = painterResource(R.drawable.bg_home),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier.fillMaxSize(),
        )

        BoxWithConstraints(Modifier.fillMaxSize()) {
            val screenHeight = maxHeight

            // Zone invisible cliquable, calée sur le bouton doré dessiné dans l'image.
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(y = screenHeight * BUTTON_TOP_FRACTION)
                    .fillMaxWidth()
                    .height(screenHeight * (BUTTON_BOTTOM_FRACTION - BUTTON_TOP_FRACTION))
                    .clickable { showNew = true },
            )

            // La liste des projets réels ne s'affiche que s'il y en a : sinon,
            // le message "Aucun projet..." déjà présent dans l'image suffit.
            if (projects.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(y = screenHeight * CREATIONS_TOP_FRACTION)
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(projects, key = { it.id }) { project ->
                            ProjectCard(
                                project = project,
                                onOpen = { onOpenProject(project.id) },
                                onRename = { renameTarget = project },
                                onDuplicate = { vm.duplicate(project.id) },
                                onDelete = { deleteTarget = project },
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        NameDialog(
            title = "Nouveau projet",
            initial = "Mon logo",
            confirmLabel = "Créer",
            onConfirm = { name ->
                showNew = false
                vm.create(name, onOpenProject)
            },
            onDismiss = { showNew = false },
        )
    }
    renameTarget?.let { target ->
        NameDialog(
            title = "Renommer",
            initial = target.name,
            confirmLabel = "Enregistrer",
            onConfirm = { name ->
                vm.rename(target.id, name)
                renameTarget = null
            },
            onDismiss = { renameTarget = null },
        )
    }
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Supprimer ce projet ?") },
            text = { Text("« ${target.name} » sera supprimé définitivement.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(target.id)
                    deleteTarget = null
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun ProjectCard(
    project: Project,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    val thumb = remember(project.id, project.updatedAt) {
        SceneRenderer.renderThumbnail(project.scene, 360).asImageBitmap()
    }
    val date = remember(project.updatedAt) {
        DateFormat.getDateInstance(DateFormat.SHORT).format(Date(project.updatedAt))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.35f)),
    ) {
        Box(Modifier.clickable(onClick = onOpen)) {
            Image(
                bitmap = thumb,
                contentDescription = project.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(Color(0xFF2A2A30)),
            )
        }
        Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text(project.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(date, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                Text(
                    "Éditer",
                    color = Gold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable(onClick = onOpen),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Renommer",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    modifier = Modifier.clickable(onClick = onRename),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Dupliquer",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    modifier = Modifier.clickable(onClick = onDuplicate),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Supprimer",
                    color = Color(0xFFE57373),
                    fontSize = 11.sp,
                    modifier = Modifier.clickable(onClick = onDelete),
                )
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                label = { Text("Nom du projet") },
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
