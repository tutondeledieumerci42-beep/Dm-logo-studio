package com.dmlogostudio.feature.editor

import com.dmlogostudio.core.model.ShapeType

val Palette: List<Long> = listOf(
    0xFFD4AF37, 0xFFFFFFFF, 0xFF111111, 0xFF8E8E93,
    0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
    0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA,
    0xFFD81B60, 0xFF6D4C41, 0xFF0B1F3A, 0xFF800020,
)

const val NO_COLOR: Long = 0x00000000

fun ShapeType.label(): String = when (this) {
    ShapeType.RECTANGLE -> "Rectangle"
    ShapeType.ROUNDED_RECTANGLE -> "Rectangle arrondi"
    ShapeType.ELLIPSE -> "Cercle / ellipse"
    ShapeType.TRIANGLE -> "Triangle"
    ShapeType.STAR -> "Étoile"
    ShapeType.POLYGON -> "Polygone"
    ShapeType.HEXAGON -> "Hexagone"
    ShapeType.OCTAGON -> "Octogone"
    ShapeType.DIAMOND -> "Losange"
    ShapeType.CROSS -> "Croix"
    ShapeType.HEART -> "Cœur"
    ShapeType.RING -> "Anneau"
    ShapeType.SEMICIRCLE -> "Demi-cercle"
    ShapeType.TRAPEZOID -> "Trapèze"
    ShapeType.PARALLELOGRAM -> "Parallélogramme"
    ShapeType.CRESCENT -> "Croissant"
    ShapeType.ARC -> "Arc de cercle"
    ShapeType.RIGHT_TRIANGLE -> "Triangle rectangle"
    ShapeType.LINE -> "Ligne droite"
    ShapeType.ARROW -> "Flèche"
    ShapeType.DOUBLE_ARROW -> "Double flèche"
    ShapeType.DASHED_LINE -> "Ligne pointillée"
    ShapeType.CURVE -> "Courbe"
    ShapeType.ZIGZAG -> "Zigzag"
    ShapeType.WAVE -> "Vague"
    ShapeType.CURVED_ARROW -> "Flèche courbée"
}

/** Lignes et flèches, regroupées sous leur propre sous-menu comme les polygones. */
val LineFamily: List<ShapeType> = listOf(
    ShapeType.LINE, ShapeType.DASHED_LINE, ShapeType.CURVE, ShapeType.ZIGZAG, ShapeType.WAVE,
    ShapeType.ARROW, ShapeType.DOUBLE_ARROW, ShapeType.CURVED_ARROW,
)

/** Formes dont le tracé est ouvert (pas de surface à remplir) : elles démarrent
 *  avec un contour visible et un remplissage transparent plutôt que l'inverse. */
val StrokeOnlyShapes: Set<ShapeType> = setOf(
    ShapeType.LINE, ShapeType.DASHED_LINE, ShapeType.CURVE, ShapeType.ZIGZAG, ShapeType.WAVE, ShapeType.CURVED_ARROW,
)

/** Formes de la famille "polygones" regroupées sous un seul sous-menu, pour que
 *  la liste principale reste courte même si d'autres formes s'ajoutent plus tard. */
val PolygonFamily: List<ShapeType> = listOf(
    ShapeType.DIAMOND, ShapeType.HEXAGON, ShapeType.OCTAGON, ShapeType.POLYGON,
)

/** Les formes géométriques réellement disponibles aujourd'hui, dans l'ordre d'affichage.
 *  La famille des polygones (losange, hexagone, octogone, polygone) n'apparaît pas ici :
 *  elle est accessible via l'entrée "Polygones" du menu, pour garder la liste courte. */
val GeometricShapes: List<ShapeType> = listOf(
    ShapeType.RECTANGLE, ShapeType.ROUNDED_RECTANGLE, ShapeType.ELLIPSE, ShapeType.TRIANGLE,
    ShapeType.STAR, ShapeType.CROSS, ShapeType.HEART, ShapeType.RING,
    ShapeType.SEMICIRCLE, ShapeType.TRAPEZOID, ShapeType.PARALLELOGRAM, ShapeType.CRESCENT,
    ShapeType.ARC, ShapeType.RIGHT_TRIANGLE,
)

/** Catégories prévues par la feuille de route mais pas encore construites : affichées
 *  pour montrer la direction du projet, jamais cliquables tant qu'elles sont vides. */
val UpcomingShapeCategories: List<String> = listOf(
    "Organiques (blob, pétales, flammes…)",
    "Emblèmes (couronnes, boucliers, médaillons…)",
    "Décoratives (rubans, cadres, badges…)",
    "Flèches",
    "Motifs (répétition, mode miroir)",
    "Dessin libre (plume, points d'ancrage)",
)

val FontFamilies: List<Pair<String, String>> = listOf(
    "sans-serif" to "Sans",
    "serif" to "Serif",
    "monospace" to "Mono",
    "cursive" to "Manuscrite",
)
