package com.dmlogostudio.feature.editor

import com.dmlogostudio.core.model.ShapeType

val Palette: List<Long> = listOf(
    0xFFD4AF37, 0xFFFFFFFF, 0xFF111111, 0xFF8E8E93,
    0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
    0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA,
    0xFFD81B60, 0xFF6D4C41, 0xFF0B1F3A, 0xFF800020,
)

const val NO_COLOR: Long = 0x00000000

fun ShapeType.label(): String = when (this) {
    ShapeType.RECTANGLE -> "Rectangle"
    ShapeType.ROUNDED_RECTANGLE -> "Rectangle arrondi"
    ShapeType.ELLIPSE -> "Cercle / ellipse"
    ShapeType.TRIANGLE -> "Triangle"
    ShapeType.STAR -> "Étoile"
    ShapeType.POLYGON -> "Polygone"
}

val FontFamilies: List<Pair<String, String>> = listOf(
    "sans-serif" to "Sans",
    "serif" to "Serif",
    "monospace" to "Mono",
    "cursive" to "Manuscrite",
)
