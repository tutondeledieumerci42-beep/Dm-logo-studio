package com.dmlogostudio.feature.editor

import com.dmlogostudio.core.model.ShapeType

val Palette: List<Long> = listOf(
    0xFFD4AF37, 0xFFFFFFFF, 0xFF111111, 0xFF8E8E93,
    0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
    0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA,
    0xFFD81B60, 0xFF6D4C41, 0xFF0B1F3A, 0xFF800020,
)

const val NO_COLOR: Long = 0x00000000

fun ShapeType.label(): String = when (this) {
    ShapeType.RECTANGLE -> "Rectangle"
    ShapeType.ROUNDED_RECTANGLE -> "Rectangle arrondi"
    ShapeType.ELLIPSE -> "Cercle / ellipse"
    ShapeType.TRIANGLE -> "Triangle"
    ShapeType.STAR -> "Étoile"
    ShapeType.POLYGON -> "Polygone"
    ShapeType.HEXAGON -> "Hexagone"
    ShapeType.OCTAGON -> "Octogone"
    ShapeType.DIAMOND -> "Losange"
    ShapeType.CROSS -> "Croix"
    ShapeType.HEART -> "Cœur"
    ShapeType.RING -> "Anneau"
    ShapeType.SEMICIRCLE -> "Demi-cercle"
    ShapeType.TRAPEZOID -> "Trapèze"
    ShapeType.PARALLELOGRAM -> "Parallélogramme"
    ShapeType.CRESCENT -> "Croissant"
}

/** Les formes géométriques réellement disponibles aujourd'hui, dans l'ordre d'affichage. */
val GeometricShapes: List<ShapeType> = listOf(
    ShapeType.RECTANGLE, ShapeType.ROUNDED_RECTANGLE, ShapeType.ELLIPSE, ShapeType.TRIANGLE,
    ShapeType.DIAMOND, ShapeType.HEXAGON, ShapeType.OCTAGON, ShapeType.POLYGON,
    ShapeType.STAR, ShapeType.CROSS, ShapeType.HEART, ShapeType.RING,
    ShapeType.SEMICIRCLE, ShapeType.TRAPEZOID, ShapeType.PARALLELOGRAM, ShapeType.CRESCENT,
)

/** Catégories prévues par la feuille de route mais pas encore construites : affichées
 *  pour montrer la direction du projet, jamais cliquables tant qu'elles sont vides. */
val UpcomingShapeCategories: List<String> = listOf(
    "Organiques (blob, pétales, flammes…)",
    "Emblèmes (couronnes, boucliers, médaillons…)",
    "Décoratives (rubans, cadres, badges…)",
    "Flèches",
    "Lignes et tracés",
    "Motifs (répétition, mode miroir)",
    "Dessin libre (plume, points d'ancrage)",
)

val FontFamilies: List<Pair<String, String>> = listOf(
    "sans-serif" to "Sans",
    "serif" to "Serif",
    "monospace" to "Mono",
    "cursive" to "Manuscrite",
)
