# PROJECT_PROGRESS — DM LOGO STUDIO

## Phase actuelle
PHASE 1 terminée. PHASE 2 en cours. v0.1.3 confirmée installée par l'utilisateur. v0.1.4 (jamais confirmée installée) : accueil = image fixe utilisateur en fond + bouton invisible superposé. Défaut rapporté par l'utilisateur avec capture : quand un projet est créé, la carte de projet se superpose au texte baked "Aucun projet pour l'instant" dans l'image (texte visible derrière la carte) -> confusion visuelle.
v0.1.5 corrige ça : DEUX images de fond intégrées (res/drawable-nodpi/bg_home.png = état vide, avec le texte "Aucun projet" et le filigrane DM baked ; bg_home_top.png = juste le titre/sous-titre/bouton, recadrée juste sous le bouton). Quand il y a au moins un projet, l'app bascule sur bg_home_top et dessine elle-même, en vrai Compose, le titre "Mes créations" + la grille de projets, donc plus aucune superposition de texte possible. Les deux images ont aussi été recadrées pour retirer la barre de navigation du bas qui était dessinée en pixels dans le screenshot d'origine (Tableau de Bord/Modèles/Paramètres), remplacée par une VRAIE barre de navigation Compose (androidx.navigation + Scaffold dans AppNav.kt) avec 3 écrans réels : Home (déjà existant), TemplatesScreen (nouveau, dit honnêtement "bientôt disponible", feature.templates), SettingsScreen (nouveau, infos réelles seulement : nom, version, stockage local, pas de connexion requise, feature.settings). La barre de navigation ne s'affiche pas dans l'éditeur. Ajout d'un léger effet de particules scintillantes (SparkleOverlay, Canvas + rememberInfiniteTransition) par-dessus la zone du bouton doré. Cartes de projet retravaillées : coins plus arrondis, liseré doré en haut, élévation, fond plus sombre dédié.

## Fonctionnalités écrites (code présent, JAMAIS compilé ni testé sur téléphone)
- Accueil : nouveau projet, liste « Mes créations » avec miniatures, renommer / dupliquer / supprimer
- Navigation accueil <-> éditeur
- Éditeur : 6 formes, textes (police, gras, italique, taille), déplacement, redimensionnement, rotation, couleurs (palette + hexadécimal), contour, opacité, fond, avant/arrière, dupliquer, supprimer, annuler/rétablir
- Sauvegarde automatique (Room, JSON de la scène)
- 7 tests unitaires (Geometry, sérialisation) — non exécutés

## Fonctionnalités restantes (ordre prévu)
Compilation vérifiée > calques complets > dégradés/ombres > export PNG/JPG/SVG/PDF > bibliothèque de formes vectorielles + recherche > TEXTURE TYPE (texture dans les lettres d'abord) > dessin main levée > mockups > Free/Premium > optimisation.

## Bugs connus
- Corrigé (v0.1.1) : textes/icônes noirs sur fond noir (« Mes créations » presque invisible) -> Surface avec couleur de contenu dans MainActivity. À revérifier sur téléphone.
- Éditeur : testé sur téléphone par l'utilisateur, fonctionne (formes, texte, couleurs, annuler/rétablir visibles et lisibles).
- v0.1.3 : accueil en dégradé, confirmé installé par l'utilisateur.
- v0.1.4 : accueil = image fixe en fond, bouton invisible superposé. Bug rapporté : superposition de texte quand un projet existe. JAMAIS confirmée corrigée (remplacée directement par v0.1.5).
- v0.1.5 : fond à deux variantes selon présence de projets, vraie barre de navigation (Home/Modèles/Paramètres) avec 2 nouveaux écrans réels, sparkles sur le bouton, cartes de projet améliorées. JAMAIS compilée ni testée. Risque connu : les fractions de position du bouton invisible (18.6%-25.5% de la hauteur) restent mesurées sur l'image source (ratio ~19.4:9) ; sur un écran à ratio très différent, un léger décalage reste possible — à vérifier après installation.

## Décisions techniques
- Module unique `app`, paquets : core.model, core.engine, data, feature.home, feature.editor, ui
- Scène = JSON immuable (Scene / LogoObject), rendu Canvas Android, annuler/rétablir par instantanés
- Room : 1 table projects (métadonnées + sceneJson)
- Pas de clé API dans l'APK ; monétisation via interfaces (Play Billing plus tard)

## Prochaine tâche
Compiler et installer v0.1.5. Vérifier : 1) plus de superposition de texte une fois un projet créé, 2) le bouton répond au bon endroit, 3) Modèles et Paramètres sont de vrais écrans qui s'ouvrent, 4) les sparkles sont visibles sans gêner la lisibilité. Ensuite démarrer l'export PNG (fonctionnalité mécanique, après le travail sur le feeling/l'interface demandé par l'utilisateur).


## Bug corrigé en v0.1.6
Build #6 a échoué sur deux erreurs dans ui/AppNav.kt, fichier nouvellement créé pour la v0.1.5 :
1. `val backStackEntry by nav.currentBackStackEntryAsState()` sans `import androidx.compose.runtime.getValue` -> "has no method getValue" (erreur classique Compose quand on utilise `by` sur un State sans cet import).
2. `Modifier.padding(innerPadding)` sans `import androidx.compose.foundation.layout.padding` -> "Unresolved reference 'padding'".
Les deux imports ont été ajoutés. Rien d'autre n'a changé dans le code entre 0.1.5 et 0.1.6.

## v0.1.7
Corrigé le défaut visuel signalé par l'utilisateur avec capture : une ligne de
jonction visible entre l'image bg_home_top et le fond uni, visible uniquement
quand un projet existe. Au lieu de deviner une couleur de dégradé Compose,
l'image bg_home_top.png a été modifiée directement (fondu pixel par pixel sur
ses 90 derniers pixels vers le noir exact du fond, 0xFF0E0E10/Ink). Le fond
Compose est maintenant une simple couleur unie Ink, sans dégradé deviné.

## v0.1.8 — Phase 1 du studio vectoriel (demande du document "MISSION : FORMES")
L'utilisateur a fourni un cahier des charges très large (bibliothèque de formes
géométriques/organiques/emblèmes/décoratives, lignes et flèches, dessin
vectoriel, fusion/soustraction/intersection, motifs, miroir, espace négatif,
bibliothèque avec recherche et favoris). Conformément à sa propre consigne
("implémentation progressive et stable plutôt qu'une intégration massive"),
seule la catégorie GÉOMÉTRIQUES a été complétée cette fois :

Ajoutées (vrai tracé Path, pas des placeholders) : Hexagone, Octogone, Losange,
Croix, Cœur (courbes de Bézier), Anneau (Path.op DIFFERENCE), Demi-cercle,
Trapèze, Parallélogramme, Croissant (Path.op DIFFERENCE). S'ajoutent aux 6
formes déjà existantes (rectangle, rectangle arrondi, cercle/ellipse,
triangle, étoile, polygone personnalisable 3-12 côtés). Toutes compatibles
automatiquement avec calques/annuler-rétablir/duplication/rotation/redimen-
sionnement puisqu'elles réutilisent le même système LogoObject/ShapeType.

Le menu Forme de l'éditeur est maintenant catégorisé : "Géométriques" (16
formes cliquables) puis "Bientôt disponible" qui liste honnêtement les 7
catégories restantes du cahier des charges (Organiques, Emblèmes,
Décoratives, Flèches, Lignes et tracés, Motifs, Dessin libre) en gris, non
cliquables — pour montrer la direction sans jamais faire semblant qu'elles
marchent.

PAS fait dans cette passe (explicitement reporté à des phases suivantes) :
formes organiques/emblèmes/décoratives (art vectoriel complexe, risque élevé
d'un rendu raté), système de lignes/flèches, dessin à main levée, outil
plume/Bézier éditable, fusion/soustraction/intersection combinant DEUX objets
sélectionnés par l'utilisateur (Path.op est faisable techniquement mais
demande une UI de sélection multiple, pas encore construite), créateur de
motifs, mode miroir, espace négatif, bibliothèque avec recherche/favoris
(actuellement un simple menu déroulant, pas une vraie grille avec aperçus).
JAMAIS compilée ni testée.

## v0.1.9 — Phase 1 de la restructuration Free/Premium (demande du document "MISSION : FREE/PREMIUM")
Conformément à l'ordre que le document impose lui-même ("Premièrement :
organisation Free/Premium"), seule la PLOMBERIE a été construite cette fois,
pas de restriction ni de vente :

- data/EntitlementRepository.kt : point central unique qui dira plus tard
  "cet utilisateur est Premium ou non" (StateFlow<Boolean>, false pour tout
  le monde actuellement). Pas de Google Play Billing branché : aucun code ne
  doit jamais simuler un achat réussi tant que ce n'est pas réellement le cas.
- feature/premium/PremiumScreen.kt : écran honnête de comparaison Free vs
  Premium, accessible depuis Paramètres > Premium (vraie navigation, pas un
  bouton mort). Il dit clairement que Premium n'est pas encore disponible à
  l'achat, que le tableau est une feuille de route et pas des fonctions déjà
  construites, et le bouton du bas est désactivé avec le texte "bientôt
  disponible" plutôt que de déclencher un faux achat.
- SettingsScreen.kt : nouvelle ligne cliquable "Premium" en haut, réelle.

PAS fait (reporté, dans l'ordre que le document propose lui-même) :
bibliothèque graphique étendue (centaines de formes), outils vectoriels
avancés (points d'ancrage, fusion/soustraction/intersection réellement
accessibles à l'utilisateur), personnalisation pro (dégradés multicouches,
ombres avancées, textures), export SVG/PDF, aucune fonctionnalité n'est
pour l'instant verrouillée derrière Premium car rien d'assez "pro" n'existe
encore à vendre — verrouiller maintenant aurait rendu Free pire sans raison,
ce que le document interdit explicitement. JAMAIS compilée ni testée.

## v0.1.10 — Comblement de trous (icône, or, polygone/hexagone, export PNG)
Quatre corrections/ajouts réels demandés par l'utilisateur, sur la base du
logo "DM LOGO STUDIO" qu'il a généré :

1. ICÔNE RÉELLE : l'icône vectorielle provisoire (hexagone doré simple) est
   remplacée par le vrai logo (D + couronne + anneau doré), recadré sans le
   texte "DM LOGO STUDIO" pour rester lisible en petite taille, avec la marge
   de sécurité standard Android pour les icônes adaptatives (contenu dans
   ~62% du canevas). Fichiers : res/drawable-nodpi/ic_launcher_foreground.png
   (remplace l'ancien res/drawable/ic_launcher_foreground.xml, supprimé).
2. OR PLUS RICHE : Gold et GoldSoft dans ui/theme/Theme.kt remplacés par des
   tons prélevés au pixel sur le logo fourni (plus saturés, plus "massifs")
   au lieu de l'or clair générique précédent.
3. POLYGONE vs HEXAGONE : bug réel repéré par l'utilisateur — le Polygone
   générique démarrait avec sa valeur par défaut (6 côtés), donc identique
   visuellement à l'Hexagone dédié. Corrigé dans EditorViewModel.addShape :
   le Polygone démarre maintenant à 5 côtés (toujours réglable de 3 à 12
   ensuite via le curseur), l'Hexagone et l'Octogone restent des raccourcis
   fixes à 6 et 8 côtés. Les trois sont maintenant visuellement distincts.
4. EXPORT PNG RÉEL (première fonction d'export de tout le projet) :
   core/export/PngExporter.kt rend la scène en plein format (2048px côté
   long) et l'enregistre via MediaStore dans Images/DM Logo Studio. Un vrai
   bouton d'export (icône téléchargement) a été ajouté dans la barre du haut
   de l'éditeur, avec confirmation ou message d'échec par Toast. Fonctionne
   sans permission sur Android 10+ ; sur Android 8-9 une permission a été
   déclarée dans le manifeste mais PAS encore demandée à l'exécution (pas de
   flux de permission runtime construit) — l'export pourrait donc échouer
   sur ces très vieux appareils, auquel cas le Toast affichera "Échec de
   l'export PNG" plutôt que de planter l'application.

JAMAIS compilée ni testée. Reste explicitement non fait, reporté : calques
complets, dégradés/ombres/textures, export SVG/PDF, dessin libre, fusion/
soustraction/intersection de formes, TEXTURE TYPE, bibliothèque d'images,
mockups, tout ce qui est listé Premium. Interface (au-delà de l'or) pas
encore retravaillée, l'utilisateur a dit vouloir y revenir plus tard.

## v0.1.11 — suite du comblement de trous + mise au clair sur ce qui est bloqué
Réponse à une longue liste de demandes. Fait aujourd'hui, réellement :

1. ICÔNE RE-CORRIGÉE : le problème signalé ("contour rongé", mal centrée)
   venait du fait que le PNG utilisé comme avant-plan contenait encore le
   cadre doré arrondi du badge d'origine, qui entrait en conflit avec le
   masque que chaque lanceur Android applique par-dessus. Le glyphe (D +
   couronne + anneau) a été isolé SEUL, fond rendu transparent par seuillage
   de luminosité, sans aucun cadre concurrent, posé sur le fond uni Ink. Plus
   de risque de double-bordure selon le lanceur utilisé.
2. RECHERCHE DE PROJETS : vrai champ de recherche sur l'accueil (filtre par
   nom, insensible à la casse), visible dès qu'il y a au moins un projet.
3. POLYGONES REGROUPÉS : losange, hexagone, octogone et polygone
   personnalisable sont sortis de la liste principale et regroupés derrière
   une entrée "Polygones ▸" qui ouvre un sous-menu dédié — la liste
   principale reste courte, comme demandé, même si d'autres formes
   s'ajoutent plus tard.
4. CORBEILLE RÉELLE : suppression devenue réversible. ProjectEntity a un
   champ deletedAt (null = actif) ; "Supprimer" déplace maintenant vers la
   corbeille au lieu d'effacer directement. Nouvel écran feature/trash/
   TrashScreen.kt (Restaurer / Supprimer définitivement), accessible depuis
   Paramètres. ATTENTION : la base de données locale a changé de version (1
   -> 2) avec fallbackToDestructiveMigration() — PAS de vraie migration
   écrite pour l'instant (projet encore en phase de test). Conséquence
   concrète : au premier lancement de cette mise à jour précise, les projets
   déjà enregistrés sur le téléphone (ex. "Mon logo", "F.A.H", "X-phantom")
   seront effacés une fois, la base étant recréée vide. Ça ne se reproduira
   pas aux mises à jour suivantes tant que le schéma ne change pas encore.

PAS fait, et pourquoi (demandé dans le même message) :
- COMPTES GOOGLE / CONNEXION (1 compte Free, jusqu'à 10 en Premium) : PAS
  commencé. Ce n'est pas une question de temps mais de dépendance externe
  réelle — Google Sign-In exige de créer un projet dans la Google Cloud
  Console / Firebase, d'y enregistrer l'empreinte SHA-1 de l'app et d'obtenir
  un identifiant client OAuth. Seul l'utilisateur, propriétaire du compte
  Google, peut faire cette étape ; je ne peux pas la faire à sa place ni la
  deviner. Sans ça, le code ne pourrait pas être testé ni même compiler
  correctement (il manquerait le fichier google-services.json). À reprendre
  quand l'utilisateur pourra fournir ces informations.
- SÉPARER "Accueil" (tableau de bord) et "Studio" (liste des projets) en
  deux onglets distincts : l'utilisateur a laissé champ libre. Choix fait de
  NE PAS ajouter un onglet supplémentaire pour l'instant : l'accueil actuel
  sert déjà d'identité (fond du logo, bouton doré) ET de liste de projets, et
  dupliquer ça en deux écrans aurait un coût réel (navigation plus complexe,
  état à synchroniser) pour un bénéfice pas évident. Cette décision peut être
  révisée si l'utilisateur la conteste.
- EXPORT VERS D'AUTRES FORMATS (SVG/PDF) : reporté, déjà sur la feuille de
  route existante, l'utilisateur lui-même n'était pas sûr que ce soit utile
  maintenant.
- FINIR TOUTES LES FORMES (organiques, emblèmes, lignes/flèches, dessin à la
  main, outil plume) EN UNE SEULE FOIS : refusé explicitement malgré la
  demande, car ça contredit la propre consigne de l'utilisateur dans le tout
  premier document ("implémentation progressive et stable plutôt qu'une
  intégration massive qui risque de casser l'application"). Reste sur la
  feuille de route, à faire par étapes.

JAMAIS compilée ni testée.

## v0.1.12 — fin de la catégorie "Formes géométriques" + correction du demi-cercle
- MUSIQUE : idée mise de côté par l'utilisateur lui-même (licences libres
  décevantes après vérification de son côté) ; reprise prévue plus tard avec
  de la musique générée sur mesure plutôt que des morceaux existants.
- INTERFACE : demande trop vague pour agir sans casser quelque chose
  ("finis l'interface si possible") ; l'or plus riche de la v0.1.10
  s'applique déjà partout car centralisé dans le thème. En attente d'une
  demande précise avant tout nouveau changement visuel large.
- BUG RÉEL CORRIGÉ : le Demi-cercle (SEMICIRCLE) était mal construit — son
  dôme se dessinait entièrement hors du cadre de sélection de l'objet (au-
  dessus, décalé), repéré par l'utilisateur en le voyant à l'écran. Nouvelle
  construction vérifiée par un calcul séparé avant envoi : base plate en bas
  du cadre, sommet du dôme exactement en haut du cadre.
- DERNIÈRES FORMES GÉOMÉTRIQUES : Arc de cercle (bande épaisse en C, 270°)
  et Triangle rectangle (forme géométrique asymétrique demandée par le
  premier document formes, angle droit dans un coin plutôt qu'un sommet
  centré). Avec ça, la catégorie "Formes géométriques" du tout premier
  document formes est maintenant ENTIÈREMENT terminée (18 formes).
JAMAIS compilée ni testée.

## v0.1.13 — Lignes et flèches (catégorie B du document formes)
Suite de la feuille de route, sans attendre : Ligne droite, Flèche (une
pointe), Double flèche. Réutilisent entièrement le système LogoObject/
ShapeType existant — pas de nouveau champ de données, pas de nouvelle
mécanique : déplacement, rotation (pour orienter la ligne), redimensionnement
(longueur), duplication, calques et annuler/rétablir fonctionnent avec elles
automatiquement. Regroupées sous un sous-menu "Lignes et flèches ▸", comme
les polygones. La Ligne droite démarre avec un contour visible par défaut
(doré, 10px) et un remplissage transparent, puisqu'une ligne n'a pas de
surface à remplir ; les flèches gardent un remplissage plein classique.
Retirées de la liste "Bientôt disponible" en conséquence.

PAS fait, toujours sur la feuille de route : lignes courbes/zigzag/en
pointillés (tracés plus avancés que la ligne droite), dessin à main levée,
outil plume à points d'ancrage modifiables, formes organiques, emblèmes,
fusion/soustraction/intersection, calques avancés, dégradés, export SVG/PDF.
JAMAIS compilée ni testée.

## v0.1.14 — correctif de compilation + suite de "Lignes et tracés"
BUG CORRIGÉ (empêchait Build #14 de compiler) : dans HomeScreen.kt, l'icône
de recherche ajoutée en v0.1.11 était écrite en chemin complet
(androidx.compose.material.icons.Icons.Filled.Search) au lieu d'être
importée. Ça ne marche pas pour ce type précis d'icône (propriété
d'extension définie dans un autre paquet) : "Unresolved reference 'Search'".
Corrigé avec un vrai import. Leçon notée : toujours importer les icônes,
jamais les écrire en chemin complet.

Suite réelle de "Lignes et tracés" (catégorie B du document formes, que
l'utilisateur avait commencée en v0.1.13 avec Ligne/Flèche/Double flèche) :
- Ligne pointillée (vrai effet pointillé au rendu, DashPathEffect)
- Courbe simple
- Zigzag
- Vague
- Flèche courbée (tracé courbe + chevron orienté selon la vraie tangente de
  la courbe à son extrémité, calculée, pas devinée)
8 éléments au total dans le sous-menu "Lignes et flèches ▸" maintenant.
Changement annexe : le rendu de TOUS les contours (pas seulement les
nouvelles lignes) utilise maintenant des jonctions et extrémités arrondies
(Paint.Join.ROUND / Paint.Cap.ROUND) au lieu d'anguleuses — nécessaire pour
que les tracés ouverts aient des bouts visibles et propres ; effet
secondaire mineur et plutôt positif sur les anciennes formes (coins de
contour légèrement arrondis au lieu de pointus).

PAS fait, encore sur la feuille de route pour "Lignes et tracés" : spirale,
flèche circulaire, extrémités personnalisables (styles de bout de ligne
configurables), tracés libres (main levée). JAMAIS compilée ni testée.

## v0.1.15 — cause racine du "Application non installée" trouvée et corrigée + Dessin à main levée
BUG D'INFRASTRUCTURE IMPORTANT, identifié aujourd'hui : "Application non
installée" revenait à CHAQUE mise à jour depuis le tout début du projet, pas
par accident. Cause réelle : GitHub Actions utilise une machine neuve à
chaque compilation, et sans clé de débogage fixe, Gradle en générait une
ALÉATOIRE et DIFFÉRENTE à chaque fois. Android refuse par sécurité
d'installer une appli signée avec une clé différente de celle déjà
installée sous le même nom de paquet, d'où l'erreur systématique.
Corrigé : une clé de débogage fixe (keystore/debug.keystore) a été générée
et ajoutée au dépôt, et app/build.gradle.kts la référence maintenant
explicitement pour le buildType debug. Conséquence pratique : CETTE mise à
jour (v0.1.15) nécessite encore UNE DERNIÈRE désinstallation manuelle avant
d'installer (nouvelle clé, différente de toutes les précédentes), mais à
partir de maintenant, les mises à jour futures s'installeront proprement
PAR-DESSUS les anciennes, sans jamais avoir à désinstaller.

DESSIN À MAIN LEVÉE, terminé dans la même mise à jour (version simple, pas
encore l'éditeur de points) :
- Nouveau bouton "Dessiner" dans la barre d'outils de l'éditeur, qui bascule
  le canevas en mode dessin (reste actif pour plusieurs traits de suite,
  jusqu'à le désactiver).
- En mode dessin, glisser le doigt capture un tracé en direct (aperçu doré
  visible pendant le geste) ; relâcher crée un vrai objet du projet.
- Astuce technique pour éviter tout code spécial : les points du tracé sont
  normalisés entre -1 et 1 par rapport à leur propre cadre au moment du
  dessin (core/model/FreehandPoint), donc le tracé hérite AUTOMATIQUEMENT du
  déplacement, de la rotation, de la duplication, des calques et du
  redimensionnement déjà existants pour toutes les autres formes — aucune
  mécanique nouvelle à maintenir séparément.

PAS fait, reporté explicitement à une étape séparée et plus avancée : outil
plume avec points d'ancrage modifiables un par un, lissage automatique des
tracés irréguliers, correction des imperfections. Cette version-ci enregistre
le tracé tel quel, sans retouche possible après coup autrement qu'en le
redessinant.

## v0.1.16 — correctif de compilation (3 erreurs, toutes dans le dessin libre de la v0.1.15)
Build #16 a échoué. Mes erreurs :
1. EditorScreen.kt : `Icons.Filled.Edit` écrit en chemin complet au lieu
   d'être importé (même type d'erreur que pour "Search" en v0.1.14 —
   corrigé cette fois en ajoutant un vrai import plutôt qu'en re-tombant
   dans le même piège).
2. EditorScreen.kt : `Gold` utilisé sans import de
   com.dmlogostudio.ui.theme.Gold.
3. Palette.kt : la fonction label() n'avait pas de cas pour
   ShapeType.FREEHAND (ajouté à l'énumération en v0.1.15 pour le dessin
   libre), rendant le "when" non exhaustif. Ajouté : "Dessin libre".
Vérifié qu'aucun autre "when" sur ShapeType dans le projet n'avait le même
oubli avant de renvoyer. Aucun changement de fonctionnalité, uniquement des
corrections. La clé de signature fixe (v0.1.15) reste en place : toujours
une désinstallation nécessaire une dernière fois avant cette version, plus
aucune ensuite.
