# PROJECT_PROGRESS — DM LOGO STUDIO

## Phase actuelle
PHASE 1 terminée. PHASE 2 en cours. v0.1.3 confirmée installée par l'utilisateur. v0.1.4 (jamais confirmée installée) : accueil = image fixe utilisateur en fond + bouton invisible superposé. Défaut rapporté par l'utilisateur avec capture : quand un projet est créé, la carte de projet se superpose au texte baked "Aucun projet pour l'instant" dans l'image (texte visible derrière la carte) -> confusion visuelle.
v0.1.5 corrige ça : DEUX images de fond intégrées (res/drawable-nodpi/bg_home.png = état vide, avec le texte "Aucun projet" et le filigrane DM baked ; bg_home_top.png = juste le titre/sous-titre/bouton, recadrée juste sous le bouton). Quand il y a au moins un projet, l'app bascule sur bg_home_top et dessine elle-même, en vrai Compose, le titre "Mes créations" + la grille de projets, donc plus aucune superposition de texte possible. Les deux images ont aussi été recadrées pour retirer la barre de navigation du bas qui était dessinée en pixels dans le screenshot d'origine (Tableau de Bord/Modèles/Paramètres), remplacée par une VRAIE barre de navigation Compose (androidx.navigation + Scaffold dans AppNav.kt) avec 3 écrans réels : Home (déjà existant), TemplatesScreen (nouveau, dit honnêtement "bientôt disponible", feature.templates), SettingsScreen (nouveau, infos réelles seulement : nom, version, stockage local, pas de connexion requise, feature.settings). La barre de navigation ne s'affiche pas dans l'éditeur. Ajout d'un léger effet de particules scintillantes (SparkleOverlay, Canvas + rememberInfiniteTransition) par-dessus la zone du bouton doré. Cartes de projet retravaillées : coins plus arrondis, liseré doré en haut, élévation, fond plus sombre dédié.

## Fonctionnalités écrites (code présent, JAMAIS compilé ni testé sur téléphone)
- Accueil : nouveau projet, liste « Mes créations » avec miniatures, renommer / dupliquer / supprimer
- Navigation accueil <-> éditeur
- Éditeur : 6 formes, textes (police, gras, italique, taille), déplacement, redimensionnement, rotation, couleurs (palette + hexadécimal), contour, opacité, fond, avant/arrière, dupliquer, supprimer, annuler/rétablir
- Sauvegarde automatique (Room, JSON de la scène)
- 7 tests unitaires (Geometry, sérialisation) — non exécutés

## Fonctionnalités restantes (ordre prévu)
Compilation vérifiée > calques complets > dégradés/ombres > export PNG/JPG/SVG/PDF > bibliothèque de formes vectorielles + recherche > TEXTURE TYPE (texture dans les lettres d'abord) > dessin main levée > mockups > Free/Premium > optimisation.

## Bugs connus
- Corrigé (v0.1.1) : textes/icônes noirs sur fond noir (« Mes créations » presque invisible) -> Surface avec couleur de contenu dans MainActivity. À revérifier sur téléphone.
- Éditeur : testé sur téléphone par l'utilisateur, fonctionne (formes, texte, couleurs, annuler/rétablir visibles et lisibles).
- v0.1.3 : accueil en dégradé, confirmé installé par l'utilisateur.
- v0.1.4 : accueil = image fixe en fond, bouton invisible superposé. Bug rapporté : superposition de texte quand un projet existe. JAMAIS confirmée corrigée (remplacée directement par v0.1.5).
- v0.1.5 : fond à deux variantes selon présence de projets, vraie barre de navigation (Home/Modèles/Paramètres) avec 2 nouveaux écrans réels, sparkles sur le bouton, cartes de projet améliorées. JAMAIS compilée ni testée. Risque connu : les fractions de position du bouton invisible (18.6%-25.5% de la hauteur) restent mesurées sur l'image source (ratio ~19.4:9) ; sur un écran à ratio très différent, un léger décalage reste possible — à vérifier après installation.

## Décisions techniques
- Module unique `app`, paquets : core.model, core.engine, data, feature.home, feature.editor, ui
- Scène = JSON immuable (Scene / LogoObject), rendu Canvas Android, annuler/rétablir par instantanés
- Room : 1 table projects (métadonnées + sceneJson)
- Pas de clé API dans l'APK ; monétisation via interfaces (Play Billing plus tard)

## Prochaine tâche
Compiler et installer v0.1.5. Vérifier : 1) plus de superposition de texte une fois un projet créé, 2) le bouton répond au bon endroit, 3) Modèles et Paramètres sont de vrais écrans qui s'ouvrent, 4) les sparkles sont visibles sans gêner la lisibilité. Ensuite démarrer l'export PNG (fonctionnalité mécanique, après le travail sur le feeling/l'interface demandé par l'utilisateur).
