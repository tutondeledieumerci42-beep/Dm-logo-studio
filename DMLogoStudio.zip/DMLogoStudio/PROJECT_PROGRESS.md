# PROJECT_PROGRESS — DM LOGO STUDIO

## Phase actuelle
PHASE 1 terminée. PHASE 2 en cours. v0.1.3 compilée, installée et CONFIRMÉE par l'utilisateur (texte de version visible, nouveau design en dégradé visible). L'utilisateur juge le rendu Compose pas assez fidèle à l'image IA qu'il avait générée comme référence. v0.1.4 : accueil remplacé par l'image exacte fournie par l'utilisateur (res/drawable-nodpi/bg_home.png, recadrée pour retirer la barre de statut du screenshot d'origine), posée en fond plein écran avec ContentScale.Crop. Les éléments réellement fonctionnels (bouton Nouveau projet, liste de projets) sont des zones Compose invisibles/transparentes superposées, positionnées par fractions de hauteur d'écran mesurées sur l'image (bouton: 16.9%-23.2%, zone créations: à partir de 33.5%).

## Fonctionnalités écrites (code présent, JAMAIS compilé ni testé sur téléphone)
- Accueil : nouveau projet, liste « Mes créations » avec miniatures, renommer / dupliquer / supprimer
- Navigation accueil <-> éditeur
- Éditeur : 6 formes, textes (police, gras, italique, taille), déplacement, redimensionnement, rotation, couleurs (palette + hexadécimal), contour, opacité, fond, avant/arrière, dupliquer, supprimer, annuler/rétablir
- Sauvegarde automatique (Room, JSON de la scène)
- 7 tests unitaires (Geometry, sérialisation) — non exécutés

## Fonctionnalités restantes (ordre prévu)
Compilation vérifiée > calques complets > dégradés/ombres > export PNG/JPG/SVG/PDF > bibliothèque de formes vectorielles + recherche > TEXTURE TYPE (texture dans les lettres d'abord) > dessin main levée > mockups > Free/Premium > optimisation.

## Bugs connus
- Corrigé (v0.1.1) : textes/icônes noirs sur fond noir (« Mes créations » presque invisible) -> Surface avec couleur de contenu dans MainActivity. À revérifier sur téléphone.
- Éditeur : testé sur téléphone par l'utilisateur, fonctionne (formes, texte, couleurs, annuler/rétablir visibles et lisibles).
- v0.1.3 : accueil en dégradé confirmé fonctionnel et installé par l'utilisateur (design de base validé, mais jugé pas assez fidèle à l'image de référence générée par IA).
- v0.1.4 : accueil = image fixe fournie par l'utilisateur en fond d'écran + zones cliquables transparentes dessus. JAMAIS compilée. Risque connu : les fractions de position du bouton/de la liste sont mesurées sur l'image source et supposent un rapport largeur/hauteur d'écran proche de celui de l'image (688x1497, soit ~19.4:9) ; sur un écran très différent, le bouton invisible peut être légèrement décalé par rapport au bouton doré dessiné dans l'image. Les onglets bas (Tableau de Bord/Modèles/Paramètres) sont dessinés dans l'image mais SEUL le reste de l'écran est actif : Modèles et Paramètres ne mènent nulle part pour l'instant — à signaler clairement à l'utilisateur, pas à cacher.

## Décisions techniques
- Module unique `app`, paquets : core.model, core.engine, data, feature.home, feature.editor, ui
- Scène = JSON immuable (Scene / LogoObject), rendu Canvas Android, annuler/rétablir par instantanés
- Room : 1 table projects (métadonnées + sceneJson)
- Pas de clé API dans l'APK ; monétisation via interfaces (Play Billing plus tard)

## Prochaine tâche
Compiler et installer v0.1.4, vérifier que le bouton "Nouveau projet" répond bien au bon endroit (zone invisible calée sur l'image), ajuster les fractions si besoin, puis décider quoi faire des onglets Modèles/Paramètres (écrans réels, ou les retirer de l'image).
