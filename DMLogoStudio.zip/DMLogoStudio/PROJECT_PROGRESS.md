# PROJECT_PROGRESS — DM LOGO STUDIO

## Phase actuelle
PHASE 1 terminée. Build APK #1 : compilation RÉUSSIE sur GitHub Actions, APK installé sur le téléphone, écran d'accueil vérifié par capture.

## Fonctionnalités écrites (code présent, JAMAIS compilé ni testé sur téléphone)
- Accueil : nouveau projet, liste « Mes créations » avec miniatures, renommer / dupliquer / supprimer
- Navigation accueil <-> éditeur
- Éditeur : 6 formes, textes (police, gras, italique, taille), déplacement, redimensionnement, rotation, couleurs (palette + hexadécimal), contour, opacité, fond, avant/arrière, dupliquer, supprimer, annuler/rétablir
- Sauvegarde automatique (Room, JSON de la scène)
- 7 tests unitaires (Geometry, sérialisation) — non exécutés

## Fonctionnalités restantes (ordre prévu)
Compilation vérifiée > calques complets > dégradés/ombres > export PNG/JPG/SVG/PDF > bibliothèque de formes vectorielles + recherche > TEXTURE TYPE (texture dans les lettres d'abord) > dessin main levée > mockups > Free/Premium > optimisation.

## Bugs connus
- Corrigé (v0.1.1) : textes/icônes noirs sur fond noir (« Mes créations » presque invisible) -> Surface avec couleur de contenu dans MainActivity. À revérifier sur téléphone.
- Éditeur : jamais testé sur téléphone (glissement, poignées, sauvegarde).

## Décisions techniques
- Module unique `app`, paquets : core.model, core.engine, data, feature.home, feature.editor, ui
- Scène = JSON immuable (Scene / LogoObject), rendu Canvas Android, annuler/rétablir par instantanés
- Room : 1 table projects (métadonnées + sceneJson)
- Pas de clé API dans l'APK ; monétisation via interfaces (Play Billing plus tard)

## Prochaine tâche
Tester l'éditeur sur téléphone (v0.1.1), puis calques et export.
