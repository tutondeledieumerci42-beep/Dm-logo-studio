# PROJECT_PROGRESS — DM LOGO STUDIO

## Phase actuelle
PHASE 1 terminée. PHASE 2 en cours : refonte visuelle de l'accueil. v0.1.2 compilée (Build APK #3, succès) mais jamais confirmée installée côté utilisateur à cause de confusion entre plusieurs fichiers app-debug.zip téléchargés. v0.1.3 ajoute un repère "Version X.X.X" visible directement sur l'écran d'accueil pour lever toute ambiguïté.

## Fonctionnalités écrites (code présent, JAMAIS compilé ni testé sur téléphone)
- Accueil : nouveau projet, liste « Mes créations » avec miniatures, renommer / dupliquer / supprimer
- Navigation accueil <-> éditeur
- Éditeur : 6 formes, textes (police, gras, italique, taille), déplacement, redimensionnement, rotation, couleurs (palette + hexadécimal), contour, opacité, fond, avant/arrière, dupliquer, supprimer, annuler/rétablir
- Sauvegarde automatique (Room, JSON de la scène)
- 7 tests unitaires (Geometry, sérialisation) — non exécutés

## Fonctionnalités restantes (ordre prévu)
Compilation vérifiée > calques complets > dégradés/ombres > export PNG/JPG/SVG/PDF > bibliothèque de formes vectorielles + recherche > TEXTURE TYPE (texture dans les lettres d'abord) > dessin main levée > mockups > Free/Premium > optimisation.

## Bugs connus
- Corrigé (v0.1.1) : textes/icônes noirs sur fond noir (« Mes créations » presque invisible) -> Surface avec couleur de contenu dans MainActivity. À revérifier sur téléphone.
- Éditeur : testé sur téléphone par l'utilisateur, fonctionne (formes, texte, couleurs, annuler/rétablir visibles et lisibles).
- v0.1.2 (accueil redessiné : fond en dégradé, titre et bouton dorés en dégradé, monogramme DM en filigrane, cartes de projet avec actions Éditer/Renommer/Dupliquer/Supprimer) : compilée avec succès, jamais confirmée visuellement par l'utilisateur.
- v0.1.3 : ajout du texte "Version X.X.X" sur l'accueil, jamais compilée.

## Décisions techniques
- Module unique `app`, paquets : core.model, core.engine, data, feature.home, feature.editor, ui
- Scène = JSON immuable (Scene / LogoObject), rendu Canvas Android, annuler/rétablir par instantanés
- Room : 1 table projects (métadonnées + sceneJson)
- Pas de clé API dans l'APK ; monétisation via interfaces (Play Billing plus tard)

## Prochaine tâche
Compiler et installer v0.1.3, confirmer via le texte de version affiché à l'écran que le nouvel accueil s'affiche, puis démarrer l'export PNG.
