# DM LOGO STUDIO — version 0.1.0

Projet Android (Kotlin, Jetpack Compose, Room). Ouvrir le dossier dans Android Studio (Ladybug 2024.2.1 ou plus récent, JDK 17 fourni).

Contenu de cette version : accueil, navigation, création/renommage/duplication/suppression de projets,
éditeur (formes, textes, couleurs, contour, opacité, déplacement, redimensionnement, rotation, ordre des plans,
duplication, annuler/rétablir) et sauvegarde automatique dans Room.

Génération de l'APK : Build > Build Bundle(s) / APK(s) > Build APK(s)
Fichier produit : app/build/outputs/apk/debug/app-debug.apk

Tests unitaires : clic droit sur app/src/test > Run Tests (ou `gradle testDebugUnitTest`).
